using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using UnityEngine;

namespace uSource.Formats.Source.MDL
{
    [StructLayout(LayoutKind.Sequential)]
    internal struct AnimDescEntry
    {
        public mstudioanimdesc_t Desc;
        public long FilePos;
    }

    internal struct AnimBlockReader
    {
        public BinaryReader rdr;
        public long ofs;
    }

    [StructLayout(LayoutKind.Sequential)]
    internal struct mdl_animblock_t
    {
        public int datastart, dataend;
    }

    internal static class MdlAnimationLoader
    {
        internal static AnimDescEntry[] ParseAnimDescs(BinaryReader br, studiohdr_t hdr)
        {
            int sz = Marshal.SizeOf<mstudioanimdesc_t>();
            var entries = new AnimDescEntry[hdr.localanim_count];
            long basePos = hdr.localanim_offset;

            for (int i = 0; i < entries.Length; ++i)
            {
                long pos = basePos + i * sz;
                br.BaseStream.Seek(pos, SeekOrigin.Begin);
                entries[i].Desc = BinaryReaderExt.ReadStruct<mstudioanimdesc_t>(br);
                entries[i].FilePos = pos;
            }

            return entries;
        }

        internal static Dictionary<int, List<AnimationBone>> ReadAnimationData(
            BinaryReader mdl, AnimDescEntry[] entries, studiohdr_t hdr)
        {
            string mdlPath = (mdl.BaseStream as FileStream)?.Name;
            var aniMap = mdlPath != null
                ? LoadAnimBlocks(mdlPath, hdr)
                : new Dictionary<int, AnimBlockReader>();

            var result = new Dictionary<int, List<AnimationBone>>(entries.Length);
            int boneCount = hdr.bone_count;

            for (int animId = 0; animId < entries.Length; animId++)
            {
                var entry = entries[animId];
                var desc = entry.Desc;

                // Wybór źródła
                Stream src;
                long ofs;
                if (desc.animblock == 0)
                {
                    src = mdl.BaseStream;
                    ofs = desc.animindex != 0 ? entry.FilePos + desc.animindex : desc.baseptr;
                }
                else
                {
                    if (!aniMap.TryGetValue(desc.animblock, out var blk))
                        continue;
                    src = blk.rdr.BaseStream;
                    ofs = blk.ofs + desc.animindex;
                }

                if (ofs <= 0 || ofs >= src.Length)
                    continue;

                src.Seek(ofs, SeekOrigin.Begin);
                var reader = new uReader(src);

                int headerCount = desc.numlocalhierarchy > 0 ? (int)desc.numlocalhierarchy : boneCount;
                var animHeaders = ReadArraySafe<HashFuncs.mstudioanim_t>(reader, headerCount);

                var bones = new List<AnimationBone>();
                int frames = Mathf.Max(1, (int)desc.numframes);

                foreach (var h in animHeaders)
                {
                    // Jeżeli bone index jest niepoprawny – pomiń
                    if (h.bone < 0 || h.bone >= boneCount)
                        continue;

                    var ab = new AnimationBone(h.bone, h.flags, frames);

                    // Rotacje animowane
                    if ((ab.Flags & AnimationBone.STUDIO_ANIM_ANIMROT) != 0)
                        AnimationParser.ReadAnimationFrameValues(reader, hdr, ab, h, frames, true,
                            (ab.Flags & AnimationBone.STUDIO_ANIM_DELTA) != 0);

                    // Pozycje animowane
                    if ((ab.Flags & AnimationBone.STUDIO_ANIM_ANIMPOS) != 0)
                        AnimationParser.ReadAnimationFrameValues(reader, hdr, ab, h, frames, false,
                            (ab.Flags & AnimationBone.STUDIO_ANIM_DELTA) != 0);

                    // Raw rotacje
                    if ((ab.Flags & AnimationBone.STUDIO_ANIM_RAWROT) != 0)
                    {
                        var q48 = new Quaternion48();
                        reader.ReadTypeFixed(ref q48, 6);
                        ab.pQuat48 = q48.quaternion;
                    }

                    if ((ab.Flags & AnimationBone.STUDIO_ANIM_RAWROT2) != 0)
                    {
                        var q64 = new Quaternion64();
                        reader.ReadTypeFixed(ref q64, 8);
                        ab.pQuat64 = q64.quaternion;
                    }

                    // Raw pozycje
                    if ((ab.Flags & AnimationBone.STUDIO_ANIM_RAWPOS) != 0)
                    {
                        var v48 = new FVector48();
                        reader.ReadTypeFixed(ref v48, 6);
                        ab.pVec48 = v48.ToVector3();
                    }

                    // Uzupełnianie braków do pełnej liczby klatek
                    while (ab.FrameAngles.Count < frames)
                        ab.FrameAngles.Add(Vector3.zero);
                    while (ab.FramePositions.Count < frames)
                        ab.FramePositions.Add(Vector3.zero);

                    bones.Add(ab);
                }

                // Jeżeli nie ma żadnych kości animowanych – dodaj puste
                if (bones.Count == 0)
                {
                    for (int b = 0; b < boneCount; b++)
                        bones.Add(new AnimationBone((byte)b, 0, frames));
                }

                result[animId] = bones;
            }

            foreach (var v in aniMap.Values)
                v.rdr.Dispose();

            return result;
        }

        private static Dictionary<int, AnimBlockReader> LoadAnimBlocks(string mdlPath, studiohdr_t hdr)
        {
            var map = new Dictionary<int, AnimBlockReader>();
            if (hdr.animblocks_count == 0) return map;

            string ani = Path.ChangeExtension(mdlPath, ".ani");
            if (!File.Exists(ani)) return map;

            var blocks = new mdl_animblock_t[hdr.animblocks_count];
            using (var br = new BinaryReader(File.OpenRead(mdlPath)))
            {
                br.BaseStream.Seek(hdr.animblocks_index, SeekOrigin.Begin);
                for (int i = 0; i < blocks.Length; ++i)
                    blocks[i] = BinaryReaderExt.ReadStruct<mdl_animblock_t>(br);
            }

            var fs = File.OpenRead(ani);
            var rdr = new BinaryReader(fs);
            for (int i = 0; i < blocks.Length; ++i)
                if (blocks[i].datastart >= 0 && blocks[i].datastart < fs.Length)
                    map[i] = new AnimBlockReader { rdr = rdr, ofs = blocks[i].datastart };
            return map;
        }

        private static T[] ReadArraySafe<T>(uReader r, int count) where T : struct
        {
            var arr = new T[count];
            for (int i = 0; i < count; ++i)
                arr[i] = BinaryReaderExt.ReadStruct<T>(r);
            return arr;
        }
    }

    [Serializable]
    public class AnimationBone
    {
        public const int STUDIO_ANIM_ANIMPOS = 0x01;
        public const int STUDIO_ANIM_ANIMROT = 0x02;
        public const int STUDIO_ANIM_RAWROT = 0x04;
        public const int STUDIO_ANIM_RAWROT2 = 0x08;
        public const int STUDIO_ANIM_DELTA = 0x10;
        public const int STUDIO_ANIM_RAWPOS = 0x20;

        public byte Bone;
        public byte Flags;
        public int NumFrames;

        public Quaternion pQuat48;
        public Quaternion pQuat64;
        public Vector3 pVec48;

        public readonly List<Vector3> FrameAngles = new();
        public readonly List<Vector3> FramePositions = new();

        [Flags]
        public enum StudioAnimFlags : int
        {
            STUDIO_ANIM_POS = 0x01,
            STUDIO_ANIM_ROT = 0x02,
            STUDIO_ANIM_ANIMPOS = 0x04,
            STUDIO_ANIM_ANIMROT = 0x08,
            STUDIO_ANIM_DELTA = 0x10,
            STUDIO_ANIM_RAWPOS = 0x20,
            STUDIO_ANIM_RAWROT = 0x40,
            STUDIO_ANIM_RAWROT2 = 0x80
        }

        public AnimationBone(byte bone, byte flags, int numFrames)
        {
            Bone = bone;
            Flags = flags;
            NumFrames = Mathf.Max(1, numFrames);
        }

        public void ReadData(uReader br)
        {
            var delta = (Flags & STUDIO_ANIM_DELTA) != 0;

            // RLE rotation frames
            if ((Flags & STUDIO_ANIM_ANIMROT) != 0)
            {
                long startPos = br.BaseStream.Position;
                short[] offsets = br.ReadShortArray(3);
                long endPos = br.BaseStream.Position;
                var rotFrames = Enumerable.Range(0, NumFrames)
                    .Select(_ => new float[3])
                    .ToList();

                for (int i = 0; i < 3; i++)
                {
                    if (offsets[i] == 0) continue;

                    long target = startPos + offsets[i];
                    if (target < 0 || target > br.BaseStream.Length)
                    {
                        UnityEngine.Debug.LogWarning(
                            $"[AnimationBone] Nieprawidłowy offset animacji: {target}, pomijam.");
                        continue;
                    }

                    br.BaseStream.Position = target;
                    short[] values = br.ReadAnimationFrameValues(NumFrames);
                    for (int f = 0; f < values.Length; f++)
                    {
                        rotFrames[f][i] = values[f] + (delta && f > 0 ? values[f - 1] : 0f);
                    }
                }

                FrameAngles.AddRange(rotFrames.Select(v => new Vector3(v[0], v[1], v[2])));
                br.BaseStream.Position = endPos;
            }

            // RLE position frames
            if ((Flags & STUDIO_ANIM_ANIMPOS) != 0)
            {
                long startPos = br.BaseStream.Position;
                short[] offsets = br.ReadShortArray(3);
                long endPos = br.BaseStream.Position;
                var posFrames = Enumerable.Range(0, NumFrames)
                    .Select(_ => new float[3])
                    .ToList();

                for (int i = 0; i < 3; i++)
                {
                    if (offsets[i] == 0) continue;

                    long target = startPos + offsets[i];
                    if (target < 0 || target > br.BaseStream.Length)
                    {
                        UnityEngine.Debug.LogWarning(
                            $"[AnimationBone] Nieprawidłowy offset pozycji: {target}, pomijam.");
                        continue;
                    }

                    br.BaseStream.Position = target;
                    short[] values = br.ReadAnimationFrameValues(NumFrames);
                    for (int f = 0; f < values.Length; f++)
                    {
                        posFrames[f][i] = values[f] + (delta && f > 0 ? values[f - 1] : 0f);
                    }
                }

                FramePositions.AddRange(posFrames.Select(v => new Vector3(v[0], v[1], v[2])));
                br.BaseStream.Position = endPos;
            }

            // Raw rotation (48-bit)
            if ((Flags & STUDIO_ANIM_RAWROT) != 0)
            {
                var quat48 = new Quaternion48();
                br.ReadTypeFixed(ref quat48, 6);
                this.pQuat48 = quat48.quaternion;
            }

            // Raw rotation (64-bit)
            if ((Flags & STUDIO_ANIM_RAWROT2) != 0)
            {
                var quat64 = new Quaternion64();
                br.ReadTypeFixed(ref quat64, 8);
                this.pQuat64 = quat64.quaternion;
            }

            // Raw position
            if ((Flags & STUDIO_ANIM_RAWPOS) != 0)
            {
                var vec48 = new FVector48();
                br.ReadTypeFixed(ref vec48, 6);
                this.pVec48 = vec48.ToVector3();
            }
        }





        private List<Vector3> ReadAnimationFrames(uReader br, int numFrames, bool delta, string type)
        {
            var startPos = br.BaseStream.Position;
            var offsets = br.ReadShortArray(3);

            if (offsets == null || offsets.Length != 3)
                throw new InvalidDataException($"Invalid offsets array for {type} data.");

            var frames = new List<float[]>();
            for (var i = 0; i < numFrames; i++)
                frames.Add(new float[3]);

            for (var i = 0; i < 3; i++)
            {
                if (offsets[i] <= 0) continue;

                long newPosition = startPos + offsets[i];
                if (newPosition < 0 || newPosition >= br.BaseStream.Length)
                    continue;

                br.BaseStream.Position = newPosition;

                var values = br.ReadAnimationFrameValues(numFrames);
                if (values == null || values.Length != numFrames)
                    continue;

                for (var f = 0; f < values.Length; f++)
                {
                    frames[f][i] = values[f];
                    if (f > 0 && delta)
                    {
                        frames[f][i] += frames[f - 1][i];
                    }
                }
            }

            br.BaseStream.Position = startPos;

            return frames.Select(f => new Vector3(f[0], f[1], f[2])).ToList();
        }

        private static Quaternion NormalizeQuaternion(Quaternion q)
        {
            if (float.IsNaN(q.x) || float.IsNaN(q.y) || float.IsNaN(q.z) || float.IsNaN(q.w))
                return Quaternion.identity;

            return Quaternion.Normalize(q);
        }
    }
}
        