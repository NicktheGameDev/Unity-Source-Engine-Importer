    // UNITY_WRAPPED - Crowbar sources excluded from Unity compilation
    #if !UNITY_2018_1_OR_NEWER
    ﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

namespace Crowbar
{
	public class SourceMdlTexture31
	{

		public int fileNameOffset;
		public int flags;
		public double width;
		public double height;
		public double worldUnitsPerU;
		public double worldUnitsPerV;
		public int[] unknown = new int[2];

		public string thePathFileName;

	}

}
    #endif
