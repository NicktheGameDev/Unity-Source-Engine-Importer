    // UNITY_WRAPPED - Crowbar sources excluded from Unity compilation
    #if !UNITY_2018_1_OR_NEWER
    ﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

namespace Crowbar
{
	public class SourceBoneTransform10
	{

		public SourceVector matrixColumn0 = new SourceVector();
		public SourceVector matrixColumn1 = new SourceVector();
		public SourceVector matrixColumn2 = new SourceVector();
		public SourceVector matrixColumn3 = new SourceVector();

	}

}
    #endif
