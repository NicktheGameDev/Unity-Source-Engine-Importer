    // UNITY_WRAPPED - Crowbar sources excluded from Unity compilation
    #if !UNITY_2018_1_OR_NEWER
    ﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

namespace Crowbar
{
	public class SourceMdlSequence04
	{

		public double sequenceFrameIndexAsSingle;
		public int[] unknown = new int[11];
		public double unknownSingle01;
		public double unknownSingle02;
		public double unknownSingle03;
		//Public positionScaleX As Short
		//Public positionScaleY As Short
		//Public positionScaleZ As Short
		//Public rotationScaleX As Short
		//Public rotationScaleY As Short
		//Public rotationScaleZ As Short
		//Public position As SourceVector
		//Public rotation As SourceVector

		public List<SourceMdlSequenceValue04> thePositionsAndRotations;

	}

}
    #endif
