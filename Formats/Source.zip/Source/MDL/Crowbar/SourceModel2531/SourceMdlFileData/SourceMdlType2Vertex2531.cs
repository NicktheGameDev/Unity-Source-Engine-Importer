    // UNITY_WRAPPED - Crowbar sources excluded from Unity compilation
    #if !UNITY_2018_1_OR_NEWER
    ﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

namespace Crowbar
{
	public class SourceMdlType2Vertex2531
	{

		public byte positionX;
		public byte positionY;
		public byte positionZ;
		//Public positionX As SByte
		//Public positionY As SByte
		//Public positionZ As SByte

		public byte normalX;
		public byte normalY;
		//NOTE: Yes, this is intentionally out of expected order.
		public byte texCoordU;
		public byte normalZ;
		public byte texCoordV;

	}

}
    #endif
