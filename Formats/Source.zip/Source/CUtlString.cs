﻿public class CUtlString
{
}