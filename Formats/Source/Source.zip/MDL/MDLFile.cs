﻿
// MDLFile_Pro.cs — Black Mesa/XenEngine tuned importer (Unity 2022–2025)
// - Single namespace: uSource.Formats.Source.MDL (avoids type clashes)
// - Animation parsing uses MdlAnimationLoader (ParseAnimDescs + ReadAnimationData)
// - Robust RLE in loader (paired with my earlier MdlAnimationLoader fix)
// - UV2 generation guarded (only on meshes with triangles)
// - Safer eyeballs/jiggle, LODs, materials; no TODO/WIP
// Drop into: Assets/uSource-master/Formats/Source/MDL/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.Animations;
#endif
using UnityEngine;
using uSource.Formats.Source.VTF;
using uSource.MathLib;
using static HashFuncs;
using Object = UnityEngine.Object;

namespace uSource.Formats.Source.MDL
{
    [Serializable]
    public struct MdlEventInfo
    {
        public float time;
        public int   type;
        public string options;
    }

    public class MDLFile : StudioStruct
    {
        public studiohdr_t             MDL_Header;
        public string[]                MDL_BoneNames;
        public mstudiobone_t[]         MDL_StudioBones;
        public mstudiohitboxset_t[]    MDL_Hitboxsets;
        private Hitbox[][]             Hitboxes;

        public static byte[] mdldata;
        public static byte[] vvdData;

        public mstudioflexdesc_t[]         MDL_FlexDescs;
        public List<mstudiovertanim_t[]>   MDL_FlexAnims;
        private List<Dictionary<int, Vector3>> _flexLookup;
        private string[] _flexNames;

        public mstudioanimdesc_t[] MDL_AniDescriptions;
        public AniInfo[]           Animations;
        public mstudioseqdesc_t[]  MDL_SeqDescriptions;
        public SeqInfo[]           Sequences;
        public mstudioevent_t[]    MDL_Events;
        public event Action<GameObject, string> OnPhonemeEvent;

        public mstudiotexture_t[]  MDL_TexturesInfo;
        public string[]            MDL_TDirectories;
        public string[]            MDL_Textures;

        public StudioBodyPart[]    MDL_Bodyparts;
        public mstudioflex_t[]     MDL_Flexes;
        public mstudiojigglebone_t[] MDL_JiggleBones;
        public mstudioeyeball_t[]  MDL_Eyeballs;

        public bool BuildMesh = true;
        private int vertCountLOD0;

        public MDLFile(Stream input, bool parseAnims = false, bool parseHitboxes = false)
        {
            if (mdldata == null)
            {
                using var ms = new MemoryStream();
                input.Position = 0;
                input.CopyTo(ms);
                mdldata = ms.ToArray();
                input.Position = 0;
            }

            using var r = new uReader(input);
            r.ReadTypeFixed(ref MDL_Header, 392);
            if (MDL_Header.id != 0x54534449)
                throw new FileLoadException("Not an IDST-based MDL");

            // Bones
            MDL_StudioBones = new mstudiobone_t[MDL_Header.bone_count];
            MDL_BoneNames   = new string[MDL_Header.bone_count];
            for (int i = 0; i < MDL_Header.bone_count; i++)
            {
                int off = MDL_Header.bone_offset + 216 * i;
                r.ReadTypeFixed(ref MDL_StudioBones[i], 216, off);
                MDL_BoneNames[i] = r.ReadNullTerminatedString(off + MDL_StudioBones[i].sznameindex);
            }

            // Hitboxes
            if (parseHitboxes && MDL_Header.hitbox_count > 0)
            {
                MDL_Hitboxsets = new mstudiohitboxset_t[MDL_Header.hitbox_count];
                Hitboxes       = new Hitbox[MDL_Header.hitbox_count][];
                for (int h = 0; h < MDL_Header.hitbox_count; h++)
                {
                    int off = MDL_Header.hitbox_offset + 12 * h;
                    r.ReadTypeFixed(ref MDL_Hitboxsets[h], 12, off);
                    int cnt = MDL_Hitboxsets[h].numhitboxes;
                    Hitboxes[h] = new Hitbox[cnt];
                    for (int b = 0; b < cnt; b++)
                    {
                        int boff = off + MDL_Hitboxsets[h].hitboxindex + 68 * b;
                        Hitboxes[h][b].BBox = new mstudiobbox_t();
                        r.ReadTypeFixed(ref Hitboxes[h][b].BBox, 68, boff);
                    }
                }
            }

            // Jiggle bones (CLS/L4D headers compatibility)
            {
                int count = 0, index = 0;
                if (FieldExists(() => MDL_Header.numjigglebones))      count = MDL_Header.numjigglebones;
                if (FieldExists(() => MDL_Header.jiggleboneindex))     index = MDL_Header.jiggleboneindex;
                if (count == 0 && FieldExists(() => MDL_Header.numlocaljigglebones)) count = MDL_Header.numlocaljigglebones;
                if (index == 0 && FieldExists(() => MDL_Header.localjiggleboneindex)) index = MDL_Header.localjiggleboneindex;

                if (count > 0 && index > 0)
                {
                    int size = Marshal.SizeOf<mstudiojigglebone_t>();
                    long fileLen = r.BaseStream.Length;
                    long offset  = index + (MDL_Header.thisPointer == 0 ? 0 : MDL_Header.thisPointer);
                    if (offset + (long)count * size <= fileLen)
                    {
                        MDL_JiggleBones = new mstudiojigglebone_t[count];
                        r.BaseStream.Position = offset;
                        for (int i = 0; i < count; ++i) r.ReadType(ref MDL_JiggleBones[i]);
                    }
                    else MDL_JiggleBones = Array.Empty<mstudiojigglebone_t>();
                }
                else MDL_JiggleBones = Array.Empty<mstudiojigglebone_t>();
            }
               // Animations + sequences + eyeballs + events
    

            // Animations + sequences + eyeballs + events
            if (parseAnims)
            {{// Ładujemy wszystkie animacje w jednej mapie: animId -> list<AnimationBone>
var animEntries = MdlAnimationLoader.ParseAnimDescs(r, MDL_Header);
var animDataMap = MdlAnimationLoader.ReadAnimationData(r, animEntries, MDL_Header);

Animations = new AniInfo[animEntries.Length];
int boneCount = MDL_Header.bone_count;

for (int animId = 0; animId < animEntries.Length; animId++)
{
    var desc = animEntries[animId].Desc;
    string animName = r.ReadNullTerminatedString(
        MDL_Header.localanim_offset + animId * Marshal.SizeOf<mstudioanimdesc_t>() + desc.sznameindex);

    int frameCount = Mathf.Max(1, (int)desc.numframes);
    bool framesLess = frameCount < 2;
    if (framesLess) frameCount += 1;

    var aniInfo = new AniInfo
    {
        name = animName,
        studioAnim = desc,
        AnimationBones = animDataMap.TryGetValue(animId, out var list) ? list : new List<AnimationBone>(),
        PosX = new Keyframe[frameCount][],
        PosY = new Keyframe[frameCount][],
        PosZ = new Keyframe[frameCount][],
        RotX = new Keyframe[frameCount][],
        RotY = new Keyframe[frameCount][],
        RotZ = new Keyframe[frameCount][],
        RotW = new Keyframe[frameCount][],
        ScaleX = new Keyframe[frameCount][], // nowe
        ScaleY = new Keyframe[frameCount][],
        ScaleZ = new Keyframe[frameCount][]
    };

    for (int f = 0; f < frameCount; f++)
    {
        aniInfo.PosX[f] = new Keyframe[boneCount];
        aniInfo.PosY[f] = new Keyframe[boneCount];
        aniInfo.PosZ[f] = new Keyframe[boneCount];
        aniInfo.RotX[f] = new Keyframe[boneCount];
        aniInfo.RotY[f] = new Keyframe[boneCount];
        aniInfo.RotZ[f] = new Keyframe[boneCount];
        aniInfo.RotW[f] = new Keyframe[boneCount];
        aniInfo.ScaleX[f] = new Keyframe[boneCount];
        aniInfo.ScaleY[f] = new Keyframe[boneCount];
        aniInfo.ScaleZ[f] = new Keyframe[boneCount];
    }

    float fps = desc.fps > 0 ? desc.fps : 30f;

    for (int boneId = 0; boneId < boneCount; boneId++)
    {
        var sbone = MDL_StudioBones[boneId];
        var animBone = aniInfo.AnimationBones.FirstOrDefault(b => b.Bone == boneId);

        for (int f = 0; f < frameCount; f++)
        {
            float t = f / fps;
            Vector3 pos = sbone.pos;
            Vector3 rot = sbone.rot;
            Vector3 scl = Vector3.one;

            if (animBone != null)
            {
                // raw
                if ((animBone.Flags & AnimationBone.STUDIO_ANIM_RAWPOS) != 0)
                    pos = animBone.pVec48;
                if ((animBone.Flags & AnimationBone.STUDIO_ANIM_RAWROT) != 0)
                    rot = MathLibrary.ToEulerAngles(animBone.pQuat48);
                if ((animBone.Flags & AnimationBone.STUDIO_ANIM_RAWROT2) != 0)
                    rot = MathLibrary.ToEulerAngles(animBone.pQuat64);

                // animowane
                int srcF = (framesLess && f != 0) ? f - 1 : f;
                if ((animBone.Flags & AnimationBone.STUDIO_ANIM_ANIMPOS) != 0)
                    pos += animBone.FramePositions[srcF].Multiply(sbone.posscale);
                if ((animBone.Flags & AnimationBone.STUDIO_ANIM_ANIMROT) != 0)
                    rot += animBone.FrameAngles[srcF].Multiply(sbone.rotscale);
            }

            if (sbone.parent == -1)
                pos = MathLibrary.SwapY(pos);
            else
                pos.x = -pos.x;

            pos *= uLoader.UnitScale;
            rot *= Mathf.Rad2Deg;

            Quaternion q = (sbone.parent == -1)
                ? Quaternion.Euler(-90, 180, -90) * MathLibrary.AngleQuaternion(rot)
                : MathLibrary.AngleQuaternion(rot);

            aniInfo.PosX[f][boneId] = new Keyframe(t, pos.x);
            aniInfo.PosY[f][boneId] = new Keyframe(t, pos.y);
            aniInfo.PosZ[f][boneId] = new Keyframe(t, pos.z);
            aniInfo.RotX[f][boneId] = new Keyframe(t, q.x);
            aniInfo.RotY[f][boneId] = new Keyframe(t, q.y);
            aniInfo.RotZ[f][boneId] = new Keyframe(t, q.z);
            aniInfo.RotW[f][boneId] = new Keyframe(t, q.w);

            aniInfo.ScaleX[f][boneId] = new Keyframe(t, scl.x);
            aniInfo.ScaleY[f][boneId] = new Keyframe(t, scl.y);
            aniInfo.ScaleZ[f][boneId] = new Keyframe(t, scl.z);
        }
    }

    Animations[animId] = aniInfo;
}


    // Sequences (bez zmian merytorycznych)
    MDL_SeqDescriptions = new mstudioseqdesc_t[MDL_Header.localseq_count];
    Sequences           = new SeqInfo[MDL_Header.localseq_count];
    for (int seqID = 0; seqID < MDL_Header.localseq_count; seqID++)
    {
        int sequenceOffset = MDL_Header.localseq_offset + (212 * seqID);
        r.ReadTypeFixed(ref MDL_SeqDescriptions[seqID], 212, sequenceOffset);
        var Sequence = MDL_SeqDescriptions[seqID];

        var seqInfo = new SeqInfo
        {
            name = r.ReadNullTerminatedString(sequenceOffset + Sequence.szlabelindex),
            seq  = Sequence
        };

        r.BaseStream.Position = sequenceOffset + Sequence.animindexindex;
        short[] animIndices = r.ReadShortArray(Sequence.groupsize[0] * Sequence.groupsize[1]);

        var seqAnimList = new List<AniInfo>(animIndices.Length);
        for (int i = 0; i < animIndices.Length; i++)
        {
            int aID = animIndices[i];
            if ((uint)aID < (uint)Animations.Length)
                seqAnimList.Add(Animations[aID]);
        }
        seqInfo.ani = seqAnimList;
        Sequences[seqID] = seqInfo;
    }
}


            
            

                ReadMdlEvents();



                // 6) events
            }

            // Textures
            MDL_TexturesInfo = new mstudiotexture_t[MDL_Header.texture_count];
            MDL_Textures     = new string[MDL_Header.texture_count];
            for (int i = 0; i < MDL_Header.texture_count; i++)
            {
                int off = MDL_Header.texture_offset + 64 * i;
                r.ReadTypeFixed(ref MDL_TexturesInfo[i], 64, off);
                MDL_Textures[i] = r.ReadNullTerminatedString(off + MDL_TexturesInfo[i].sznameindex);
            }

            MDL_TDirectories = new string[MDL_Header.texturedir_count];
            for (int d = 0; d < MDL_Header.texturedir_count; d++)
            {
                int off = MDL_Header.texturedir_offset + 4 * d;
                int ptr = 0; r.ReadTypeFixed(ref ptr, 4, off);
                MDL_TDirectories[d] = r.ReadNullTerminatedString(ptr);
            }

            // Bodyparts + models
            MDL_Bodyparts = new StudioBodyPart[MDL_Header.bodypart_count];
            for (int bp = 0; bp < MDL_Header.bodypart_count; bp++)
            {
                int off = MDL_Header.bodypart_offset + 16 * bp;
                var bpinfo = new mstudiobodyparts_t();
                r.ReadTypeFixed(ref bpinfo, 16, off);

                var part = new StudioBodyPart
                {
                    Name   = bpinfo.sznameindex != 0 ? r.ReadNullTerminatedString(off + bpinfo.sznameindex) : string.Empty,
                    Models = new StudioModel[bpinfo.nummodels]
                };

                for (int m = 0; m < bpinfo.nummodels; m++)
                {
                    int moff = off + bpinfo.modelindex + 148 * m;
                    var mm = new mstudiomodel_t();
                    r.ReadTypeFixed(ref mm, 148, moff);
                    if (m == 0) vertCountLOD0 = mm.numvertices;

                    var sm = new StudioModel
                    {
                        isBlank       = mm.numvertices <= 0 || mm.nummeshes <= 0,
                        Model         = mm,
                        Meshes        = new mstudiomesh_t[mm.nummeshes],
                        IndicesPerLod = new Dictionary<int, List<int>>[8],
                        VerticesPerLod= new mstudiovertex_t[8][]
                    };
                    for (int i = 0; i < 8; i++) sm.IndicesPerLod[i] = new Dictionary<int, List<int>>();
                    sm.VerticesGlobalStart = mm.vertexindex;

                    if (sm.NumLODs > 0 && vertCountLOD0 > 0)
                        sm.LODRemap = r.ReadUshortArray(vertCountLOD0 * sm.NumLODs);
                    else
                        sm.LODRemap = Array.Empty<ushort>();

                    for (int s = 0; s < mm.nummeshes; s++)
                    {
                        int so = moff + mm.meshindex + 116 * s;
                        r.ReadTypeFixed(ref sm.Meshes[s], 116, so);
                    }

                    part.Models[m] = sm;
                }
                MDL_Bodyparts[bp] = part;
            }
        }

        static bool FieldExists<T>(Expression<Func<T>> expr)
        {
            if (expr.Body is MemberExpression m && m.Member is FieldInfo fi && fi.DeclaringType == typeof(studiohdr_t))
                return fi != null;
            return false;
        }

        public static MDLFile Load(string mdlPath, bool parseAnims = false, bool parseHitboxes = false)
        {
            mdldata = File.ReadAllBytes(mdlPath);
            string vvdPath = Path.ChangeExtension(mdlPath, ".vvd");
            vvdData = File.Exists(vvdPath) ? File.ReadAllBytes(vvdPath) : null;
            if (!File.Exists(vvdPath))
                Debug.LogWarning($"[MDL] VVD not found – flexes unavailable for {mdlPath}");
            using var ms = new MemoryStream(mdldata);
            return new MDLFile(ms, parseAnims, parseHitboxes);
        }

        public void SetIndices(int bp, int mdl, int lod, int mesh, List<int> idx)
            => MDL_Bodyparts[bp].Models[mdl].IndicesPerLod[lod].Add(mesh, idx);

        public void SetVertices(int bp, int mdl, int lod, int total, int start, mstudiovertex_t[] verts)
        {
            var dst = new mstudiovertex_t[total];
            Array.Copy(verts, start, dst, 0, total);
            MDL_Bodyparts[bp].Models[mdl].VerticesPerLod[lod] = dst;
        }

        public void LoadFlexData(uReader r)
        {
            try
            {
                if (vvdData == null) { LoadFlexFromBuffer(r, mdldata); return; }
                using var vr = new uReader(new MemoryStream(vvdData));
                LoadFlexFromBuffer(vr, vvdData);
            }
            catch
            {
                MDL_FlexDescs ??= Array.Empty<mstudioflexdesc_t>();
                MDL_FlexAnims ??= new List<mstudiovertanim_t[]>();
                _flexLookup   ??= new List<Dictionary<int, Vector3>>();
                _flexNames    ??= Array.Empty<string>();
            }
        }

        void LoadFlexFromBuffer(uReader rd, byte[] buf)
        {
            long len = buf?.Length ?? 0;
            if (len == 0)
            {
                MDL_FlexDescs = Array.Empty<mstudioflexdesc_t>();
                MDL_FlexAnims = new List<mstudiovertanim_t[]>();
                _flexLookup   = new List<Dictionary<int, Vector3>>();
                _flexNames    = Array.Empty<string>();
                return;
            }

            try { rd.BaseStream.Position = Math.Clamp(MDL_Header.flexdesc_index, 0, len - 1); }
            catch
            {
                MDL_FlexDescs = Array.Empty<mstudioflexdesc_t>();
                MDL_FlexAnims = new List<mstudiovertanim_t[]>();
                _flexLookup   = new List<Dictionary<int, Vector3>>();
                _flexNames    = Array.Empty<string>();
                return;
            }

            int descCnt = Math.Max(0, MDL_Header.flexdesc_count);
            MDL_FlexDescs = new mstudioflexdesc_t[descCnt];
            for (int i = 0; i < descCnt; i++)
            {
                try { rd.ReadType(ref MDL_FlexDescs[i]); }
                catch { MDL_FlexDescs[i] = default; }
            }

            _flexNames  = new string[descCnt];
            _flexLookup = new List<Dictionary<int, Vector3>>(descCnt);
            MDL_FlexAnims = new List<mstudiovertanim_t[]>(descCnt);

            int strTbl = MDL_Header.flexdesc_index + descCnt * Marshal.SizeOf<mstudioflexdesc_t>();

            for (int f = 0; f < descCnt; f++)
            {
                var d = MDL_FlexDescs[f];
                // name
                int nPos = strTbl + d.szFACSindex;
                if (nPos >= 0 && nPos < len)
                {
                    int end = Array.IndexOf(buf, (byte)0, nPos);
                    if (end < 0) end = (int)len;
                    int nLen = Math.Max(0, end - nPos);
                    _flexNames[f] = nLen > 0 ? Encoding.UTF8.GetString(buf, nPos, nLen) : $"flex_{f}";
                }
                else _flexNames[f] = $"flex_{f}";

                // verts
                if (d.vertanim_count <= 0 || d.vertanim_offset <= 0 || d.vertanim_offset >= len)
                {
                    MDL_FlexAnims.Add(Array.Empty<mstudiovertanim_t>());
                    _flexLookup.Add(new Dictionary<int, Vector3>());
                    continue;
                }

                long off = Math.Clamp(d.vertanim_offset, 0, len - 1);
                rd.BaseStream.Position = off;
                int max = (int)((len - off) / Marshal.SizeOf<mstudiovertanim_t>());
                int cnt = Math.Clamp(d.vertanim_count, 0, max);
                var arr = new mstudiovertanim_t[cnt];
                for (int v = 0; v < cnt; v++)
                {
                    try { rd.ReadType(ref arr[v]); } catch { arr[v] = default; }
                }
                MDL_FlexAnims.Add(arr);

                var dict = new Dictionary<int, Vector3>(cnt);
                foreach (var va in arr) if (va.index >= 0) dict[va.index] = va.NormalDelta;
                _flexLookup.Add(dict);
            }
        }

        public Vector3 GetFlexDelta(int fi, int vi, float s)
            => s == 0f || fi < 0 || fi >= _flexLookup.Count ? Vector3.zero
             : _flexLookup[fi].TryGetValue(vi, out var d) ? d * s : Vector3.zero;

        public string GetFlexName(int i) => (i >= 0 && i < _flexNames.Length) ? _flexNames[i] : $"flex_{i}";

        Transform[] BuildBoneHierarchy(GameObject root)
        {
            Transform[] bones = new Transform[MDL_Header.bone_count];
            for (int i = 0; i < bones.Length; i++)
            {
                var go = new GameObject(MDL_BoneNames[i]);
                bones[i] = go.transform;

                var sb = MDL_StudioBones[i];
                Vector3 p = sb.pos * uLoader.UnitScale;
                p.x = -p.x;

                if (sb.parent >= 0) bones[i].parent = bones[sb.parent];
                else
                {
                    (p.y, p.z) = (p.z, -p.y);
                    bones[i].parent = root.transform;
                }

                bones[i].localPosition = p;

                Vector3 eul = sb.rot * Mathf.Rad2Deg;
                bones[i].localRotation = sb.parent == -1
                    ? Quaternion.Euler(-90, 90, -90) * MathLibrary.AngleQuaternion(eul)
                    : MathLibrary.AngleQuaternion(eul);
            }

            if (uLoader.DrawArmature)
                root.AddComponent<MDLArmatureInfo>().boneNodes = bones;
            return bones;
        }

        void BuildHitboxes(Transform[] bones)
        {
            if (Hitboxes == null) return;
            for (int i = 0; i < Hitboxes.Length; i++)
            {
                foreach (var hb in Hitboxes[i])
                {
                    var bb = hb.BBox;
                    var bc = new GameObject($"Hitbox_{bones[bb.bone].name}").AddComponent<BoxCollider>();
                    bc.size   = MathLibrary.NegateX(bb.bbmax - bb.bbmin) * uLoader.UnitScale;
                    bc.center = MathLibrary.NegateX((bb.bbmax + bb.bbmin) / 2f) * uLoader.UnitScale;
                    bc.transform.parent = bones[bb.bone];
                    bc.transform.localPosition = Vector3.zero;
                    bc.transform.localRotation = Quaternion.identity;
                }
            }
        }

        [DisallowMultipleComponent] public class JiggleBone : MonoBehaviour
        {
            public Transform tip;
            public float stiffness = 180f;
            public float damping   = 0.75f;
            public Vector3 localRestPos;
            Vector3 _prevPos;
            void Awake(){ if (tip == null) tip = transform; _prevPos = tip.position; localRestPos = tip.localPosition; }
            void LateUpdate()
            {
                Vector3 currentPos = tip.position;
                Vector3 wantedPos  = transform.TransformPoint(localRestPos);
                Vector3 velocity   = currentPos - _prevPos;
                Vector3 force      = (wantedPos - currentPos) * stiffness * Time.deltaTime * Time.deltaTime;
                velocity += force; velocity *= 1f - damping * Time.deltaTime;
                Vector3 nextPos = currentPos + velocity;
                tip.position = nextPos; tip.rotation = transform.rotation; _prevPos = currentPos;
            }
        }

        [DisallowMultipleComponent] public class EyeController : MonoBehaviour
        {
            public Transform leftEye, rightEye, target; public float eyeSpeed = 15f;
            void LateUpdate()
            {
                if (leftEye == null && rightEye == null) return;
                Transform t = target ?? Camera.main?.transform; if (t == null) return;
                Vector3 lookPos = t.position;
                void Rot(Transform eye){ Vector3 dir = lookPos - eye.position; if (dir.sqrMagnitude < 1e-6f) return;
                    Quaternion q = Quaternion.LookRotation(dir, transform.up);
                    eye.rotation = Quaternion.Slerp(eye.rotation, q, Time.deltaTime * eyeSpeed); }
                if (leftEye)  Rot(leftEye); if (rightEye) Rot(rightEye);
            }
        }

        [DisallowMultipleComponent] public class MdlEventPlayer : MonoBehaviour
        {
            public event Action<MdlEventInfo> OnMdlEvent;
            public void Fire(int type, string options) => OnMdlEvent?.Invoke(new MdlEventInfo { time = Time.time, type = type, options = options });
        }

        void BuildEyeballs(Transform root, Transform[] bones)
        {
            if (MDL_Eyeballs == null || MDL_Eyeballs.Length == 0) return;
            var ec = root.GetComponent<EyeController>() ?? root.gameObject.AddComponent<EyeController>();
            int eyeballSize = Marshal.SizeOf<mstudioeyeball_t>();

            for (int i = 0; i < MDL_Eyeballs.Length; ++i)
            {
                var eye = MDL_Eyeballs[i];
                Vector3 src = eye.org;
                if (float.IsNaN(src.x) || float.IsNaN(src.y) || float.IsNaN(src.z)) continue;
                Vector3 pos = MathLibrary.SwapZY(MathLibrary.NegateX(src) * uLoader.UnitScale);
                if (!float.IsFinite(pos.x) || !float.IsFinite(pos.y) || !float.IsFinite(pos.z)) continue;

                Transform bone = (eye.bone >= 0 && eye.bone < bones.Length) ? bones[eye.bone] : root;
                var go = new GameObject($"Eyeball_{bone.name}_{i}");
                go.transform.SetParent(bone, false);
                go.transform.localPosition = pos;
                go.transform.localRotation = Quaternion.identity;

                string name = GetEyeballNameSafe(i, eye.sznameindex, eyeballSize).ToLowerInvariant();
                if (ec.leftEye == null && (name.Contains("left") || name.Contains("_l"))) ec.leftEye = go.transform;
                else if (ec.rightEye == null && (name.Contains("right") || name.Contains("_r"))) ec.rightEye = go.transform;
                else if (ec.leftEye == null) ec.leftEye = go.transform;
                else if (ec.rightEye == null) ec.rightEye = go.transform;
            }

            string GetEyeballNameSafe(int idx, int relOffset, int structSize)
            {
                long abs = MDL_Header.eyeball_offset + idx * structSize + relOffset;
                return GetCStringSafe((int)abs);
            }
        }

        static string GetCStringSafe(int ptr)
        {
            if (mdldata == null) return string.Empty;
            if (ptr < 0 || ptr >= mdldata.Length) return string.Empty;
            int end = Array.IndexOf(mdldata, (byte)0, ptr); if (end < 0) end = mdldata.Length;
            int len = end - ptr; return len > 0 ? Encoding.UTF8.GetString(mdldata, ptr, len) : string.Empty;
        }

        public Transform BuildModel(bool generateUV2 = false)
{
    using (var prof = uSource.Tools.ProfilerHelper.Measure("BuildModel_Total"))
    {
        if (MDL_FlexAnims == null)
        {
            using var ms = new MemoryStream(mdldata);
            using var rd = new uReader(ms);
            LoadFlexData(rd);
            Debug.Log($"[MDL] Loaded {MDL_FlexDescs?.Length ?? 0} flex descriptors, total flex anim arrays: {MDL_FlexAnims?.Count ?? 0}");
        }

        string raw = string.IsNullOrEmpty(MDL_Header.Name) ? "MDL_Model" : MDL_Header.Name;
        string clean = Path.GetFileNameWithoutExtension(raw).Replace('\\','_').Replace('/','_')
            .Replace(':','_').Replace('*','_').Replace('?','_').Replace('\"','_').Replace('<','_').Replace('>','_').Replace('|','_');
        var modelGO = new GameObject(clean);
        Transform[] bones = BuildBoneHierarchy(modelGO);

        if (MDL_Hitboxsets != null) BuildHitboxes(bones);
        if (MDL_Eyeballs != null && MDL_Eyeballs.Length > 0) BuildEyeballs(modelGO.transform, bones);
        if (MDL_JiggleBones != null && MDL_JiggleBones.Length > 0) BuildJiggleBones(bones, modelGO.transform);

        bool staticProp = MDL_Header.flags.HasFlag(StudioHDRFlags.STUDIOHDR_FLAGS_STATIC_PROP);
        var mdlEventPlayer = modelGO.GetComponent<MdlEventPlayer>() ?? modelGO.AddComponent<MdlEventPlayer>();
        if (OnPhonemeEvent != null) mdlEventPlayer.OnMdlEvent += info => OnPhonemeEvent(modelGO, info.options);

        // ───────────────────── BODY PARTS / MODELE ─────────────────────
        for (int bp = 0; bp < MDL_Header.bodypart_count; bp++)
        {
            var bodypart = MDL_Bodyparts[bp];

            for (int mi = 0; mi < bodypart.Models.Length; mi++)
            {
                var mdl = bodypart.Models[mi];
                if (mdl.isBlank) continue;

                // ZBIORNIK rendererów per LOD: LOD index -> lista rendererów
                var lodToRenderers = new Dictionary<int, List<Renderer>>(8);
                for (int i = 0; i < mdl.NumLODs; i++) lodToRenderers[i] = new List<Renderer>(4);

                Mesh baseBlendshapeMesh = null;

                // UWAGA: zawsze zaczynamy od LOD0 (żeby „LOD0 to LOD0”)
                for (int lod = 0; lod < mdl.NumLODs; lod++)
                {
                    var vs = mdl.VerticesPerLod[lod];
                    if (vs == null || vs.Length == 0) continue;

                    int vc = vs.Length;
                    var pos = new Vector3[vc];
                    var nor = new Vector3[vc];
                    var uv  = new Vector2[vc];
                    var bw  = new BoneWeight[vc];

                    for (int v = 0; v < vc; v++)
                    {
                        pos[v] = MathLibrary.SwapZY(vs[v].m_vecPosition * uLoader.UnitScale);
                        nor[v] = MathLibrary.SwapZY(vs[v].m_vecNormal);
                        var t  = vs[v].m_vecTexCoord; if (uLoader.SaveAssetsToUnity && uLoader.ExportTextureAsPNG) t.y = 1 - t.y;
                        uv[v]  = t;
                        bw[v]  = GetBoneWeightSafe(vs[v].m_BoneWeights);
                    }

                    string baseName = Path.GetFileNameWithoutExtension(mdl.Model.Name).Trim('.', '_').Replace(" ", "_");
                    foreach (char c in Path.GetInvalidFileNameChars()) baseName = baseName.Replace(c, '_');
                    if (string.IsNullOrEmpty(baseName)) baseName = "Mesh";
                    string meshName = $"{baseName}_LOD{lod}";

                    var mesh = new Mesh { name = meshName };
                    mesh.subMeshCount = mdl.Model.nummeshes;
                    mesh.vertices = pos; mesh.normals = nor; mesh.uv = uv;
                    mesh.bindposes = bones.Select(b => b.worldToLocalMatrix * modelGO.transform.localToWorldMatrix).ToArray();
                    mesh.boneWeights = bw;

                    for (int s = 0; s < mdl.Model.nummeshes; s++)
                        mesh.SetTriangles(mdl.IndicesPerLod[lod][s], s);

                    mesh.ClearBlendShapes();

                    bool willBeSkinned = !staticProp;
                    if (willBeSkinned && MDL_FlexDescs != null && MDL_FlexDescs.Length > 0)
                    {
                        int vFirst = mdl.VerticesGlobalStart;
                        try
                        {
                            bool gotBlend = AddBlendshapesFromFlex(mesh, mdl.VerticesPerLod[lod], vFirst);
                            if (gotBlend && baseBlendshapeMesh == null) { BuildAdvancedBlendshapes(mesh); baseBlendshapeMesh = mesh; }
                            else if (baseBlendshapeMesh != null && lod > 0 && mdl.LODRemap != null && mdl.LODRemap.Length > 0)
                                CloneFlexToLOD(baseBlendshapeMesh, mesh, mdl.LODRemap);
                        }
                        catch (Exception e) { Debug.LogWarning($"[MDLFile] Blendshape/flex apply failed for {mesh.name}: {e.Message}"); }
                    }

                    // GO dla mesha
                    var go = new GameObject($"{meshName}_GO");
                    go.transform.SetParent(modelGO.transform, false);

                    Renderer renderer;
                    if (!staticProp)
                    {
                        var sren = go.AddComponent<SkinnedMeshRenderer>();
                        renderer = sren;
                        Matrix4x4[] bindPoses = new Matrix4x4[bones.Length];
                        for (int i = 0; i < bindPoses.Length; i++)
                            bindPoses[i] = bones[i].worldToLocalMatrix * go.transform.localToWorldMatrix;
                        mesh.boneWeights = bw; mesh.bindposes = bindPoses;
                        sren.sharedMesh = mesh; sren.rootBone = bones[0]; sren.bones = bones; sren.updateWhenOffscreen = true;
                    }
                    else
                    {
                        var mf = go.AddComponent<MeshFilter>();
                        renderer = go.AddComponent<MeshRenderer>();
                        mf.sharedMesh = mesh;
                    }

                    renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.TwoSided;

                    // Materiały
                    Material[] mats = new Material[mesh.subMeshCount];
                    for (int meshID = 0; meshID < mdl.Model.nummeshes; meshID++)
                    {
                        string materialPath;
                        int lastDir = MDL_TDirectories.Length - 1;
                        for (int dir = 0; dir < MDL_TDirectories.Length; dir++)
                        {
                            materialPath = MDL_TDirectories[dir] + MDL_Textures[mdl.Meshes[meshID].material];

                            if (uResourceManager.ContainsFile(materialPath, uResourceManager.MaterialsSubFolder, uResourceManager.MaterialsExtension[0]))
                            {
                                var VMT = uResourceManager.LoadMaterial(materialPath);
                                mats[meshID] = VMT.Material;
                                break;
                            }
                            else if (dir == lastDir)
                                mats[meshID] = uResourceManager.LoadMaterial(string.Empty).Material;
                        }
                    }
                    renderer.sharedMaterials = mats;

#if UNITY_EDITOR
                    if (generateUV2)
                    {
                        bool hasTris = false;
                        for (int si = 0; si < mesh.subMeshCount; si++)
                            if (mesh.GetTriangles(si).Length > 0) { hasTris = true; break; }

                        if (hasTris)
                        {
                            var so = new UnityEditor.SerializedObject(renderer);
                            so.FindProperty("m_ScaleInLightmap").floatValue = uLoader.ModelsLightmapSize;
                            so.ApplyModifiedProperties();
                            go.isStatic = true;
                            uResourceManager.UV2GenerateCache.Add(mesh);
                        }
                        else
                            Debug.LogWarning($"[MDLFile] Skipping UV2 for {mesh.name} – no triangles.");
                    }
#endif
                    // Do kubełka LOD-owego wg prawdziwego indeksu
                    lodToRenderers[lod].Add(renderer);
                }

                // ─────────────── UTWÓRZ LODGROUP DLA TEGO MODELU ───────────────
                // kontener LODGroup jako rodzic WSZYSTKICH mesh-ów modelu
                var lodRoot = new GameObject($"{mdl.Model.Name}_LODGroup");
                lodRoot.transform.SetParent(modelGO.transform, false);
                var group = lodRoot.AddComponent<LODGroup>();
                group.fadeMode = LODFadeMode.CrossFade;

                // pomocnicze dzieci LOD0, LOD1… (organizacja + spełnienie Twojego wymogu „parent of per all meshes”)
                var lodChildGOs = new Dictionary<int, Transform>();
                for (int l = 0; l < mdl.NumLODs; l++)
                {
                    var child = new GameObject($"LOD{l}").transform;
                    child.SetParent(lodRoot.transform, false);
                    lodChildGOs[l] = child;
                }

                // przepnij wszystkie GO rendererów pod odpowiednie LODx
                foreach (var kv in lodToRenderers)
                {
                    int l = kv.Key;
                    foreach (var r in kv.Value)
                        r.transform.SetParent(lodChildGOs[l], true);
                }

                // policz progi ekranu – zawsze malejące: LOD0 > LOD1 > … > LODn
                float[] heights = ComputeLODHeights(mdl);

                // zbuduj LOD[] w KOLEJNOŚCI indeksów (bez sortowań!)
                var lodList = new List<UnityEngine.LOD>(mdl.NumLODs);
                for (int l = 0; l < mdl.NumLODs; l++)
                {
                    var rs = lodToRenderers[l].Where(r => r != null).ToArray();
                    if (rs.Length == 0) continue; // brak rendererów dla tego poziomu
                    lodList.Add(new UnityEngine.LOD(heights[l], rs));
                }

                if (lodList.Count > 0)
                {
                    group.SetLODs(lodList.ToArray());
                    group.RecalculateBounds();
                }
            }
        }

        SetupAnimatorAndClips(modelGO, bones);
        if (MDL_Header.flags.HasFlag(StudioHDRFlags.STUDIOHDR_FLAGS_STATIC_PROP))
            modelGO.transform.eulerAngles = new Vector3(0, 90, 0);

        return modelGO.transform;
    }
}

// ───────────────────────────── helpers ─────────────────────────────
private static float[] ComputeLODHeights(StudioModel mdl)
{
    int n = Mathf.Max(1, mdl.NumLODs);
    var h = new float[n];

    // Jeżeli Source podał sensowne switchPointy – znormalizuj je do 0..1 i odwróć,
    // tak aby LOD0 miał najwyższy próg, a dalsze coraz mniejsze.
    bool haveSwitch = true;
    float maxSp = 0f;
    for (int i = 0; i < n; i++)
    {
        float sp = mdl.LODData[i].switchPoint;
        if (sp < 0) { haveSwitch = false; break; }
        maxSp = Mathf.Max(maxSp, sp);
    }

    if (haveSwitch && maxSp > 0.0001f)
    {
        for (int i = 0; i < n; i++)
        {
            // duży switchPoint = użyj przy małej wielkości na ekranie
            float sp = mdl.LODData[i].switchPoint;
            h[i] = Mathf.Clamp01(1f - (sp / maxSp) * 0.98f);
        }
    }
    else
    {
        // Fallback: równomierne progi (działają w każdej grze)
        float start = 0.7f;   // LOD0
        float end   = 0.02f;  // ostatni LOD
        for (int i = 0; i < n; i++)
        {
            float t = (n == 1) ? 0f : (float)i / (n - 1);
            h[i] = Mathf.Lerp(start, end, t);
        }
    }

    // Wymuś ściśle malejącą sekwencję (Unity tego wymaga)
    for (int i = 1; i < n; i++)
        if (h[i] >= h[i - 1])
            h[i] = Mathf.Max(0.01f, h[i - 1] - 0.01f);

    return h;
}

// MDLFile class scope (same level as BuildEyeballs / SetupAnimatorAndClips)
private void BuildJiggleBones(Transform[] bones, Transform root)
{
    if (MDL_JiggleBones == null || MDL_JiggleBones.Length == 0) return;

    foreach (var jb in MDL_JiggleBones)
    {
        int i = jb.bone;
        if (i < 0 || i >= bones.Length) continue;

        var t = bones[i];

        // Reuse the helper component
        var comp = t.GetComponent<JiggleBone>() ?? t.gameObject.AddComponent<JiggleBone>();
        comp.tip          = t;
        comp.localRestPos = Vector3.zero;
        comp.stiffness    = Mathf.Clamp(jb.Stiffness, 10f, 900f);
        comp.damping      = Mathf.Clamp01(jb.yawDamping);
    }
}

        void ReadMdlEvents()
        {
            if (MDL_SeqDescriptions == null) { MDL_Events = Array.Empty<mstudioevent_t>(); return; }
            var list = new List<mstudioevent_t>();
            using var ms = new MemoryStream(mdldata, false);
            using var r = new uReader(ms);
            int sz = Marshal.SizeOf<mstudioevent_t>();

            for (int s = 0; s < MDL_SeqDescriptions.Length; s++)
            {
                var sd = MDL_SeqDescriptions[s];
                if (sd.numevents == 0) continue;
                long baseOff = MDL_Header.localseq_offset + 212 * s;
                for (int e = 0; e < sd.numevents && list.Count < 1000; e++)
                {
                    var ev = new mstudioevent_t();
                    r.ReadTypeFixed(ref ev, sz, (int)(baseOff + sd.eventindex + e * sz));
                    list.Add(ev);
                }
            }
            MDL_Events = list.ToArray();
        }


     
        void SetupAnimatorAndClips(GameObject root, Transform[] bones)
        {
            using (var prof = uSource.Tools.ProfilerHelper.Measure("SetupAnimatorAndClips"))
            {
                var bonePathDict = new Dictionary<int, string>(MDL_Header.bone_count);
                Animator animatorComponent = root.GetComponent<Animator>();
                if (animatorComponent == null)
                {
                    Debug.LogWarning($"Animator component missing on {root.name}. Adding one.");
                    animatorComponent = root.AddComponent<Animator>();
                }

                const string controllerDir = "Assets/GeneratedAnimatorControllers";
                if (!Directory.Exists(controllerDir))
                    Directory.CreateDirectory(controllerDir);
                AssetDatabase.Refresh();

                string cleanName = $"{root.name}_{Guid.NewGuid()}".Replace(".", "_").Replace("/", "_").Replace("\\", "_");
                string controllerPath = $"{controllerDir}/{cleanName}_AnimatorController.controller";
                var controller = AnimatorController.CreateAnimatorControllerAtPath(controllerPath);

                if (controller.layers.Length == 0)
                    controller.AddLayer(new AnimatorControllerLayer { name = "Base Layer", stateMachine = new AnimatorStateMachine() });

                var stateMachine = controller.layers[0].stateMachine;
                animatorComponent.runtimeAnimatorController = controller;

                const string exportDir = "Assets/ExportedAnimations";
                if (!Directory.Exists(exportDir))
                    Directory.CreateDirectory(exportDir);

                for (int i = 0; i < MDL_Header.bone_count; i++)
                {
                    var seg = new List<string>();
                    for (int c = i; c != -1; c = MDL_StudioBones[c].parent)
                        seg.Add(MDL_BoneNames[c]);
                    seg.Reverse();
                    bonePathDict[i] = string.Join("/", seg);
                }

                if (Sequences != null)
                {
                    foreach (var seq in Sequences)
                    {
                        if (seq.ani == null) continue;
                        foreach (var ani in seq.ani)
                        {
                            var clip = CreateAnimationClip(ani, bonePathDict);
                            clip.name = ani.name.Replace(" ", "_");

                            var state = stateMachine.AddState(clip.name);
                            state.motion = clip;

                            string p = clip.name;

                            if (controller.parameters.All(x => x.name != $"{p}_Bool"))
                                controller.AddParameter($"{p}_Bool", AnimatorControllerParameterType.Bool);
                            if (controller.parameters.All(x => x.name != $"{p}_Trigger"))
                                controller.AddParameter($"{p}_Trigger", AnimatorControllerParameterType.Trigger);
                            if (controller.parameters.All(x => x.name != $"{p}_Float"))
                                controller.AddParameter($"{p}_Float", AnimatorControllerParameterType.Float);
                            if (controller.parameters.All(x => x.name != $"{p}_Int"))
                                controller.AddParameter($"{p}_Int", AnimatorControllerParameterType.Int);

                            AnimatorStateTransition t;
                            t = stateMachine.AddAnyStateTransition(state);
                            t.hasExitTime = false; t.duration = 0f; t.AddCondition(AnimatorConditionMode.If, 0, $"{p}_Bool");
                            t = stateMachine.AddAnyStateTransition(state);
                            t.hasExitTime = false; t.duration = 0f; t.AddCondition(AnimatorConditionMode.IfNot, 0, $"{p}_Bool");
                            t = stateMachine.AddAnyStateTransition(state);
                            t.hasExitTime = false; t.duration = 0f; t.AddCondition(AnimatorConditionMode.If, 0, $"{p}_Trigger");
                            const float floatThreshold = 0.5f;
                            t = stateMachine.AddAnyStateTransition(state);
                            t.hasExitTime = false; t.duration = 0f; t.AddCondition(AnimatorConditionMode.Greater, floatThreshold, $"{p}_Float");
                            t = stateMachine.AddAnyStateTransition(state);
                            t.hasExitTime = false; t.duration = 0f; t.AddCondition(AnimatorConditionMode.Less, floatThreshold, $"{p}_Float");
                            const int intValue = 1;
                            t = stateMachine.AddAnyStateTransition(state);
                            t.hasExitTime = false; t.duration = 0f; t.AddCondition(AnimatorConditionMode.Equals, intValue, $"{p}_Int");
                            t = stateMachine.AddAnyStateTransition(state);
                            t.hasExitTime = false; t.duration = 0f; t.AddCondition(AnimatorConditionMode.NotEqual, intValue, $"{p}_Int");

#if UNITY_EDITOR
                            string desiredPath = $"{exportDir}/{clip.name}.anim";
                            string uniquePath = AssetDatabase.GenerateUniqueAssetPath(desiredPath);
                            AssetDatabase.CreateAsset(clip, uniquePath);
                            AssetDatabase.SaveAssets();
#endif
                            Debug.Log($"AnimationClip '{clip.name}' exported to {exportDir}");
                        }
                    }

#if UNITY_EDITOR
                    Avatar avatar = null;
                    bool isHumanoid =
                        MDL_BoneNames.Any(b => b.Equals("ValveBiped.Hips", StringComparison.OrdinalIgnoreCase)) &&
                        MDL_BoneNames.Any(b => b.Equals("ValveBiped.Head", StringComparison.OrdinalIgnoreCase));

                    if (isHumanoid)
                    {
                        avatar = AvatarBuilder.BuildHumanAvatar(root, Hu(root, MDL_BoneNames));
                    }
                    else
                    {
                        avatar = AvatarBuilder.BuildGenericAvatar(root, root.name);
                    }

                    animatorComponent.avatar = avatar;
#if UNITY_EDITOR
                    avatar = AvatarBuilder.BuildGenericAvatar(root, MDL_BoneNames[0]);
                    animatorComponent.avatar = avatar;
#endif
                    Debug.Log($"{root.name} - Avatar built ({(isHumanoid ? "Humanoid" : "Generic")})");
#endif
                }

                if (animatorComponent.runtimeAnimatorController != null)
                    animatorComponent.runtimeAnimatorController = Object.Instantiate(animatorComponent.runtimeAnimatorController);
            }
        }

        static void AddParamIfMissing(UnityEditor.Animations.AnimatorController c, string name, AnimatorControllerParameterType t)
        { if (c.parameters.All(p => p.name != name)) c.AddParameter(name, t); }

        static void CreateAnyState(UnityEditor.Animations.AnimatorStateMachine sm,
            UnityEditor.Animations.AnimatorState to, AnimatorConditionMode mode, float thr, string param)
        { var tr = sm.AddAnyStateTransition(to); tr.hasExitTime = false; tr.duration = 0f; tr.AddCondition(mode, thr, param); }

        private static BoneWeight GetBoneWeightSafe(mstudioboneweight_t src)
        {
            int[] b = new int[4]; float[] w = new float[4];
            b[0] = src.bone[0]; b[1] = src.bone[1]; b[2] = src.bone[2]; b[3] = 0;
            w[0] = src.weight[0]; w[1] = src.weight[1]; w[2] = src.weight[2]; w[3] = Mathf.Max(0f, 1f - (w[0]+w[1]+w[2]));
            Array.Sort(w, b); Array.Reverse(w); Array.Reverse(b);
            float sum = w[0]+w[1]+w[2]+w[3];
            if (sum > 0f){ float inv = 1f/sum; for (int i=0;i<4;i++) w[i]*=inv; } else { w[0]=1f; w[1]=w[2]=w[3]=0f; }
            return new BoneWeight{ boneIndex0=b[0], weight0=w[0], boneIndex1=b[1], weight1=w[1], boneIndex2=b[2], weight2=w[2], boneIndex3=b[3], weight3=w[3] };
        }

     
         public AnimationClip CreateAnimationClip(AniInfo animationData, Dictionary<int, string> bonePathDict)
  {
      using (var prof = uSource.Tools.ProfilerHelper.Measure("CreateAnimationClip"))
      {
          int numFrames = animationData.studioAnim.numframes < 2
              ? animationData.studioAnim.numframes + 1
              : animationData.studioAnim.numframes;
          AnimationClip clip = new AnimationClip { legacy = false };

          int boneCount = MDL_Header.bone_count;
          AnimationCurve[] posX = new AnimationCurve[boneCount];
          AnimationCurve[] posY = new AnimationCurve[boneCount];
          AnimationCurve[] posZ = new AnimationCurve[boneCount];
          AnimationCurve[] rotX = new AnimationCurve[boneCount];
          AnimationCurve[] rotY = new AnimationCurve[boneCount];
          AnimationCurve[] rotZ = new AnimationCurve[boneCount];
          AnimationCurve[] rotW = new AnimationCurve[boneCount];
          for (int i = 0; i < boneCount; i++)
          {
              posX[i] = new AnimationCurve();
              posY[i] = new AnimationCurve();
              posZ[i] = new AnimationCurve();
              rotX[i] = new AnimationCurve();
              rotY[i] = new AnimationCurve();
              rotZ[i] = new AnimationCurve();
              rotW[i] = new AnimationCurve();
          }

          for (int frame = 0; frame < numFrames; frame++)
          {
              for (int bone = 0; bone < boneCount; bone++)
              {
                  posX[bone].AddKey(animationData.PosX[frame][bone]);
                  posY[bone].AddKey(animationData.PosY[frame][bone]);
                  posZ[bone].AddKey(animationData.PosZ[frame][bone]);
                  rotX[bone].AddKey(animationData.RotX[frame][bone]);
                  rotY[bone].AddKey(animationData.RotY[frame][bone]);
                  rotZ[bone].AddKey(animationData.RotZ[frame][bone]);
                  rotW[bone].AddKey(animationData.RotW[frame][bone]);
              }
          }

          for (int bone = 0; bone < boneCount; bone++)
          {
              if (!bonePathDict.TryGetValue(bone, out string bonePath) || string.IsNullOrEmpty(bonePath)) continue;

              clip.SetCurve(bonePath, typeof(Transform), "localPosition.x", posX[bone]);
              clip.SetCurve(bonePath, typeof(Transform), "localPosition.y", posY[bone]);
              clip.SetCurve(bonePath, typeof(Transform), "localPosition.z", posZ[bone]);
              clip.SetCurve(bonePath, typeof(Transform), "localRotation.x", rotX[bone]);
              clip.SetCurve(bonePath, typeof(Transform), "localRotation.y", rotY[bone]);
              clip.SetCurve(bonePath, typeof(Transform), "localRotation.z", rotZ[bone]);
              clip.SetCurve(bonePath, typeof(Transform), "localRotation.w", rotW[bone]);
          }

          if (animationData.studioAnim.fps > 0f)
              clip.frameRate = animationData.studioAnim.fps;

          clip.EnsureQuaternionContinuity();
          return clip;
      }
  }
        // ------- Flex helpers (unchanged public surface) -------
        bool AddBlendshapesFromFlex(Mesh mesh, mstudiovertex_t[] verts, int baseOfs)
        {
            int vc = verts.Length; if (vc == 0) return false;
            bool any = false;
            for (int fi = 0; fi < (MDL_FlexDescs?.Length ?? 0); fi++)
            {
                string rawName = GetFlexName(fi);
                string safeName = SanitizeBlendshapeName(rawName);
                if (mesh.GetBlendShapeIndex(safeName) != -1) continue;

                var dV = new Vector3[vc]; var dN = new Vector3[vc]; bool hasAny = false;
                var flexAnims = MDL_FlexAnims[fi];
                for (int vi = 0; vi < flexAnims.Length; vi++)
                {
                    var va = flexAnims[vi];
                    int localIdx = va.index - baseOfs; if ((uint)localIdx >= (uint)vc) continue;
                    if (va.PositionDelta.sqrMagnitude < 1e-10f && va.NormalDelta.sqrMagnitude < 1e-10f) continue;
                    dV[localIdx] = MathLibrary.SwapZY(va.PositionDelta * uLoader.UnitScale);
                    dN[localIdx] = MathLibrary.SwapZY(va.NormalDelta); hasAny = true;
                }
                if (!hasAny) continue;
                mesh.AddBlendShapeFrame(safeName, 100f, dV, dN, null); any = true;

                string smoothName = $"_{safeName}_smooth";
                if (mesh.GetBlendShapeIndex(smoothName) == -1)
                {
                    var dvCopy = (Vector3[])dV.Clone(); var dnCopy = (Vector3[])dN.Clone();
                    Sanitize(dvCopy, mesh); mesh.AddBlendShapeFrame(smoothName, 100f, dvCopy, dnCopy, null);
                }
            }
            return any;
        }

        static string SanitizeBlendshapeName(string name)
        {
            if (string.IsNullOrEmpty(name)) return "blendshape";
            var sb = new StringBuilder();
            foreach (char c in name) { if (char.IsLetterOrDigit(c) || c=='_' || c=='-') sb.Append(c); else if (char.IsWhiteSpace(c)) sb.Append('_'); }
            string cleaned = sb.ToString(); if (cleaned.Length > 64) cleaned = cleaned[..64]; if (string.IsNullOrEmpty(cleaned)) cleaned = "blendshape"; return cleaned;
        }

        void BuildAdvancedBlendshapes(Mesh mesh)
        {
            int vCount = mesh.vertexCount;
            var dv = new Vector3[vCount]; var dn = new Vector3[vCount]; var tmp = new Vector3[vCount];
            var symPairs = new (string left, string right)[]{("Smile_L","Smile_R"),("Blink_L","Blink_R"),("CheekPuff_L","CheekPuff_R"),("BrowRaise_L","BrowRaise_R"),("Frown_L","Frown_R"),("Squint_L","Squint_R")};
            for (int i=0;i<symPairs.Length;i++)
            {
                var (left,right) = symPairs[i]; int iL = mesh.GetBlendShapeIndex(left); int iR = mesh.GetBlendShapeIndex(right); if (iL==-1 && iR==-1) continue;
                var dL = new Vector3[vCount]; var nL = new Vector3[vCount]; var dR = new Vector3[vCount]; var nR = new Vector3[vCount];
                if (iL!=-1) mesh.GetBlendShapeFrameVertices(iL,0,dL,nL,tmp);
                if (iR!=-1) mesh.GetBlendShapeFrameVertices(iR,0,dR,nR,tmp);
                string both = left.TrimEnd('_','L');
                if (mesh.GetBlendShapeIndex(both)==-1){ for (int v=0; v<vCount; ++v){ dv[v]=(dL[v]+MirrorX(dR[v]))*0.5f; dn[v]=(nL[v]+MirrorX(nR[v]))*0.5f; } Sanitize(dv,mesh); mesh.AddBlendShapeFrame(both,100f,dv,dn,null); }
                if (iL==-1 && iR!=-1){ for (int v=0; v<vCount; ++v){ dv[v]=MirrorX(dR[v]); dn[v]=MirrorX(nR[v]); } Sanitize(dv,mesh); mesh.AddBlendShapeFrame(left,100f,dv,dn,null); }
                else if (iR==-1 && iL!=-1){ for (int v=0; v<vCount; ++v){ dv[v]=MirrorX(dL[v]); dn[v]=MirrorX(nL[v]); } Sanitize(dv,mesh); mesh.AddBlendShapeFrame(right,100f,dv,dn,null); }
            }
            mesh.RecalculateNormals();
            int count = mesh.blendShapeCount;
            for (int bs=0; bs<count; ++bs){ string name = mesh.GetBlendShapeName(bs); if (name.StartsWith("_")) continue;
                mesh.GetBlendShapeFrameVertices(bs,0,dv,dn,tmp); Sanitize(dv,mesh); mesh.AddBlendShapeFrame($"_{name}_smooth",100f,dv,dn,null); }
            static Vector3 MirrorX(Vector3 v)=> new(-v.x,v.y,v.z);
        }

        static void Sanitize(Vector3[] delta, Mesh m)
        {
            int vCount = m.vertexCount;
            var verts = m.vertices;
            List<int>[] adj; float[] maxEdge;
            if (!_staticAdjCache.TryGetValue(m.GetInstanceID(), out adj)){ adj = BuildAdjacency(m); _staticAdjCache[m.GetInstanceID()] = adj; }
            if (!_staticMaxEdgeCache.TryGetValue(m.GetInstanceID(), out maxEdge)){ maxEdge = CacheMaxEdgeLengths(m, adj); _staticMaxEdgeCache[m.GetInstanceID()] = maxEdge; }

            var buckets = new Dictionary<long, List<int>>(vCount);
            for (int i=0;i<vCount;++i){ long key = QuantizeKey(verts[i]); if (!buckets.TryGetValue(key, out var list)){ list=new List<int>(2); buckets[key]=list; } list.Add(i); }
            foreach (var kv in buckets.Values){ if (kv.Count<2) continue; Vector3 avg=Vector3.zero; foreach (int idx in kv) avg+=delta[idx]; avg/=kv.Count; foreach (int idx in kv) delta[idx]=avg; }
            for (int v=0; v<delta.Length; ++v){ float max = maxEdge[v]*.95f; float mag = delta[v].magnitude; if (mag>max) delta[v]*=max/mag; }
            static long QuantizeKey(Vector3 p){ int x=(int)(p.x*10000f); int y=(int)(p.y*10000f); int z=(int)(p.z*10000f);
                return ((long)(x & 0x1FFFFF) << 42) | ((long)(y & 0x1FFFFF) << 21) | (long)(z & 0x1FFFFF); }
        }
        private static readonly Dictionary<int, List<int>[]> _staticAdjCache = new(); private static readonly Dictionary<int, float[]> _staticMaxEdgeCache = new();
        static List<int>[] BuildAdjacency(Mesh m)
        {
            int vCount = m.vertexCount; var adj = new List<int>[vCount]; for (int i=0;i<vCount;++i) adj[i]=new List<int>(6);
            var tris = m.triangles; for (int t=0; t<tris.Length; t+=3){ int a=tris[t], b=tris[t+1], c=tris[t+2]; Add(a,b); Add(a,c); Add(b,c); }
            void Add(int x,int y){ var lx=adj[x]; if (!lx.Contains(y)) lx.Add(y); var ly=adj[y]; if (!ly.Contains(x)) ly.Add(x); }
            return adj;
        }
        static float[] CacheMaxEdgeLengths(Mesh m, List<int>[] adj)
        { var verts=m.vertices; int vCount=verts.Length; var max=new float[vCount];
          for (int v=0; v<vCount; ++v){ float best=0f; foreach (int n in adj[v]){ float d=(verts[v]-verts[n]).magnitude; if (d>best) best=d; } max[v]=best; } return max; }

        private Texture2D[] CloneFlexToLOD(Mesh src, Mesh dst, ushort[] remap)
        {
            if (src == null || dst == null || remap == null || remap.Length == 0) return null;
            int srcBSCount = src.blendShapeCount; if (srcBSCount == 0) return null;
            int dstVC = dst.vertexCount; var tmp = new Vector3[Mathf.Max(src.vertexCount, dstVC)];
            for (int shapeIndex = 0; shapeIndex < srcBSCount; shapeIndex++)
            {
                string shapeName = src.GetBlendShapeName(shapeIndex); if (dst.GetBlendShapeIndex(shapeName) != -1) continue;
                int frameCount = src.GetBlendShapeFrameCount(shapeIndex);
                for (int frame = 0; frame < frameCount; frame++)
                {
                    float weight = src.GetBlendShapeFrameWeight(shapeIndex, frame);
                    var srcDV = new Vector3[src.vertexCount]; var srcDN = new Vector3[src.vertexCount];
                    src.GetBlendShapeFrameVertices(shapeIndex, frame, srcDV, srcDN, tmp);
                    var dstDV = new Vector3[dstVC]; var dstDN = new Vector3[dstVC];
                    for (int v = 0; v < dstVC; v++)
                    { if (v >= remap.Length) continue; int srcIdx = remap[v]; if (srcIdx >= 0 && srcIdx < srcDV.Length){ dstDV[v] = srcDV[srcIdx]; dstDN[v] = srcDN[srcIdx]; } }
                    dst.AddBlendShapeFrame(shapeName, weight, dstDV, dstDN, null);
                }
            }
            dst.RecalculateBounds(); return null;
        }

#if UNITY_EDITOR
        public static HumanDescription Hu(GameObject root, string[] mdlNames)
        {
            var hList = new List<HumanBone>(); var sList = new List<SkeletonBone>();
            foreach (var t in root.GetComponentsInChildren<Transform>(true))
            {
                string src = t.name; if (TryMap(src, out string dst))
                    hList.Add(new HumanBone { boneName = src, humanName = dst, limit = new HumanLimit { useDefaultValues = true } });
                sList.Add(new SkeletonBone { name = src, position = t.localPosition, rotation = t.localRotation, scale = t.localScale });
            }
            Ensure("ValveBiped.Bip01_Pelvis", HumanBodyBones.Hips.ToString());
            Ensure("ValveBiped.Bip01_Head1",  HumanBodyBones.Head.ToString());
            return new HumanDescription
            {
                human = hList.ToArray(), skeleton = sList.ToArray(),
                armStretch=.05f, legStretch=.05f, upperArmTwist=.5f, lowerArmTwist=.5f,
                upperLegTwist=.5f, lowerLegTwist=.5f, feetSpacing=0, hasTranslationDoF=false
            };
            void Ensure(string src, string dst){ if (hList.Any(b=>b.humanName==dst)) return; if (!mdlNames.Contains(src)) return;
                hList.Add(new HumanBone{ boneName=src, humanName=dst, limit=new HumanLimit{ useDefaultValues=true } }); }
        }
        static bool TryMap(string valve, out string unity)
        {
            unity = valve switch
            {
                "ValveBiped.Bip01_Pelvis"   => HumanBodyBones.Hips.ToString(),
                "ValveBiped.Bip01_Spine"    => HumanBodyBones.Spine.ToString(),
                "ValveBiped.Bip01_Spine1"   => HumanBodyBones.Chest.ToString(),
                "ValveBiped.Bip01_Spine2"   => HumanBodyBones.UpperChest.ToString(),
                "ValveBiped.Bip01_Neck1"    => HumanBodyBones.Neck.ToString(),
                "ValveBiped.Bip01_Head1"    => HumanBodyBones.Head.ToString(),
                "ValveBiped.Bip01_L_Clavicle" => HumanBodyBones.LeftShoulder.ToString(),
                "ValveBiped.Bip01_L_UpperArm" => HumanBodyBones.LeftUpperArm.ToString(),
                "ValveBiped.Bip01_L_Forearm"  => HumanBodyBones.LeftLowerArm.ToString(),
                "ValveBiped.Bip01_L_Hand"     => HumanBodyBones.LeftHand.ToString(),
                "ValveBiped.Bip01_R_Clavicle" => HumanBodyBones.RightShoulder.ToString(),
                "ValveBiped.Bip01_R_UpperArm" => HumanBodyBones.RightUpperArm.ToString(),
                "ValveBiped.Bip01_R_Forearm"  => HumanBodyBones.RightLowerArm.ToString(),
                "ValveBiped.Bip01_R_Hand"     => HumanBodyBones.RightHand.ToString(),
                "ValveBiped.Bip01_L_Thigh"    => HumanBodyBones.LeftUpperLeg.ToString(),
                "ValveBiped.Bip01_L_Calf"     => HumanBodyBones.LeftLowerLeg.ToString(),
                "ValveBiped.Bip01_L_Foot"     => HumanBodyBones.LeftFoot.ToString(),
                "ValveBiped.Bip01_L_Toe0"     => HumanBodyBones.LeftToes.ToString(),
                "ValveBiped.Bip01_R_Thigh"    => HumanBodyBones.RightUpperLeg.ToString(),
                "ValveBiped.Bip01_R_Calf"     => HumanBodyBones.RightLowerLeg.ToString(),
                "ValveBiped.Bip01_R_Foot"     => HumanBodyBones.RightFoot.ToString(),
                "ValveBiped.Bip01_R_Toe0"     => HumanBodyBones.RightToes.ToString(),
                _ => null
            };
            return !string.IsNullOrEmpty(unity);
        }
#endif

        public enum DetailMode { None, Lowest, Low, Medium, High }
    }
}
