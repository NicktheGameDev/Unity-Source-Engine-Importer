// Assets/Editor/QcAssetImporter.cs
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using USource.Model.Flex;

public class QcAssetImporter : AssetPostprocessor
{
    static void OnPostprocessAllAssets(
        string[] importedAssets,
        string[] deletedAssets,
        string[] movedAssets,
        string[] movedFromAssetPaths)
    {
        foreach (var path in importedAssets)
        {
            if (!path.EndsWith(".qc"))
                continue;

            // Parse QC data (returns a QC info object with controllers, flexNames, fps)
            var qcData = QcFlexDataImporter.ParseQc(path);
            if (qcData == null)
                continue;

            // Create or get the ScriptableObject asset
            var soPath = Path.ChangeExtension(path, ".qc.asset");
            QcFlexData qcSo = AssetDatabase.LoadAssetAtPath<QcFlexData>(soPath);
            bool isNew = false;
            if (qcSo == null)
            {
                qcSo = ScriptableObject.CreateInstance<QcFlexData>();
                AssetDatabase.CreateAsset(qcSo, soPath);
                isNew = true;
            }

            // Copy data into the SO
            qcSo.controllers = qcData.controllers;
            qcSo.flexNames = qcData.flexNames;
            qcSo.fps = qcData.fps;

            // Mark dirty and save
            EditorUtility.SetDirty(qcSo);
            if (isNew)
                AssetDatabase.ImportAsset(soPath);
        }
    }
}
