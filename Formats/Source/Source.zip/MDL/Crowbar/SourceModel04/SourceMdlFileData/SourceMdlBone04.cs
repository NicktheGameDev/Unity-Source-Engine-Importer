    // UNITY_WRAPPED - Crowbar sources excluded from Unity compilation
    #if !UNITY_2018_1_OR_NEWER
    ﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

namespace Crowbar
{
	public class SourceMdlBone04
	{

		public int parentBoneIndex;
		public int unknown;
		public SourceVector position = new SourceVector();
		//Public positionX As Short
		//Public positionY As Short
		//Public positionZ As Short
		//Public rotationX As Short
		//Public rotationY As Short
		//Public rotationZ As Short
		//Public positionX As New SourceFloat16bits()
		//Public positionY As New SourceFloat16bits()
		//Public positionZ As New SourceFloat16bits()
		//Public rotationX As New SourceFloat16bits()
		//Public rotationY As New SourceFloat16bits()
		//Public rotationZ As New SourceFloat16bits()

	}

}
    #endif
