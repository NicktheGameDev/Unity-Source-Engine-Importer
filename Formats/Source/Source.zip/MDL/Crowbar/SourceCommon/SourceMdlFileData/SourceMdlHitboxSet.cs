    // UNITY_WRAPPED - Crowbar sources excluded from Unity compilation
    #if !UNITY_2018_1_OR_NEWER
    ﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

namespace Crowbar
{
	public class SourceMdlHitboxSet
	{

		//FROM: public\studio.h
		//struct mstudiohitboxset_t
		//{
		//	int					sznameindex;
		//	inline char * const	pszName( void ) const { return ((char *)this) + sznameindex; }
		//	int					numhitboxes;
		//	int					hitboxindex;
		//	inline mstudiobbox_t *pHitbox( int i ) const { return (mstudiobbox_t *)(((byte *)this) + hitboxindex) + i; };
		//};


		public int nameOffset;
		public int hitboxCount;
		public int hitboxOffset;


		public string theName;
		public List<SourceMdlHitbox> theHitboxes;

	}

}
    #endif
