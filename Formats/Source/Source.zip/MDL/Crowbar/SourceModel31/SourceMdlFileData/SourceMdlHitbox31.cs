    // UNITY_WRAPPED - Crowbar sources excluded from Unity compilation
    #if !UNITY_2018_1_OR_NEWER
    ﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

namespace Crowbar
{
	public class SourceMdlHitbox31
	{

		public int boneIndex;
		public int groupIndex;
		public SourceVector boundingBoxMin = new SourceVector();
		public SourceVector boundingBoxMax = new SourceVector();

	}

}
    #endif
