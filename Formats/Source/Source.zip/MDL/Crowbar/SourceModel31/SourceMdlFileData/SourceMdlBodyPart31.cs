    // UNITY_WRAPPED - Crowbar sources excluded from Unity compilation
    #if !UNITY_2018_1_OR_NEWER
    ﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

namespace Crowbar
{
	public class SourceMdlBodyPart31
	{

		public int nameOffset;
		public int modelCount;
		public int @base;
		public int modelOffset;

		public List<SourceMdlModel31> theModels;
		public string theName;

	}

}
    #endif
