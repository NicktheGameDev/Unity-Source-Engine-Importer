﻿public class MStudioSeqDesc
{
}