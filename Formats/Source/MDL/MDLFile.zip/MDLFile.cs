﻿
// This is the cleaned and consolidated MDLFile script.
// It now exclusively uses Unity's Animation system and avoids duplication.
// Reference logic from MDLFile number 2 was used.


/*
 * Enhanced MDLFile Script for Unity
 * Features:
 * - Comprehensive support for Source Engine MDL features including animations, flexes, jiggle bones, and eyeball tracking.
 * - Modular and clear structure for easy maintenance.
 */


using JetBrains.Annotations;

using System;
using System.Collections.Generic;
using System.ComponentModel;

using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using UnityEditor;

#if UNITY_EDITOR
using UnityEditor.Animations;
using UnityEditor.PackageManager.UI;

using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.Events;
using UnityEngine.XR;
using uSource;
using uSource.Formats.Source.MDL;
using uSource.Formats.Source.VTF;
using uSource.MathLib;
using static uSource.Formats.Source.MDL.StudioStruct;



// --- End of Improved Solution ---
namespace uSource.Formats.Source.MDL
{


    public class MDLFile : StudioStruct
    {
        public studiohdr_t MDL_Header;

        public mstudioflex_t[] MDL_Flexes;
        public mstudiojigglebone_t[] MDL_JiggleBones;
        public mstudioflexdesc_t[] MDL_FlexDescs;
        private const int MAX_EVENTS_ALLOWED = 1000;

        public mstudioeyeball_t[] MDL_Eyeballs { get; set; } // Array example

        public String[] MDL_BoneNames;
        public mstudiobone_t[] MDL_StudioBones;


        public mstudioseqdesc_t[] MDL_SeqDescriptions;

        public mstudioanimdesc_t[] MDL_AniDescriptions;

        public AniInfo[] Animations;
        public SeqInfo[] Sequences;

        private static mstudioevent_t[] MDL_Events;
        public bool EnableFlexes { get; set; } = true;
        public bool EnableJiggleBones { get; set; } = true;
        public bool EnableEyeMovement { get; set; } = true;
        public mstudiotexture_t[] MDL_TexturesInfo;
        public String[] MDL_TDirectories;
        public String[] MDL_Textures;

        mstudiohitboxset_t[] MDL_Hitboxsets;
        Hitbox[][] Hitboxes;
        /// <summary>
        /// Dodaje blendshapes na podstawie danych flexów zawartych w modelu MDL.
        /// </summary>
        /// <param name="mesh">Siatka modelu, do której dodawane są blendshapes.</param>
        /// <param name="mdlData">Surowe dane MDL.</param>
        /// <param name="baseOffset">Podstawowy offset danych.</param>
        /// 
        public enum DetailMode
        {
            None, // Parse all lod's
            Lowest, // Parse only last lod's
            Low, // Parse only low lod's
            Medium, // Parse only mid lod's
            High // Parse only high lod's
        }


        private void Use_OnTriggerEnter()
        {
            OnTriggerEnter();

        }



        private void Use_PopulateKeyframesForAnimation()


        {
            PopulateKeyframesForAnimation(new int(), new int(), new AniInfo(), new mstudiobone_t[0]);

        }






        private void Use_UpdateProceduralBones() { UpdateProceduralBones(Time.deltaTime); }




        // --- Improved Solution for AnimationOverrideController Issue ---

        public static void Use_AnimationClipCreator() { var instance = new AnimationClipCreator(); Debug.Log("Instance of AnimationClipCreator created."); }

        public void ProcessModel(GameObject modelObject)
        {
            Debug.Log($"Processing model: {MDL_Header.Name}");

            if (EnableFlexes && MDL_Flexes != null)
            {
                ProcessFlexes(modelObject);
            }


            if (EnableJiggleBones && MDL_JiggleBones != null)
            {
                ApplyJiggleBones(modelObject);
            }

            if (EnableEyeMovement && MDL_Eyeballs != null)
            {
                ApplyEyeMovement(modelObject);
            }


        }
        private void ApplyJiggleBones(GameObject modelObject)
        {
            Debug.Log("Applying jiggle bones...");

            if (MDL_JiggleBones == null || MDL_JiggleBones.Length == 0)
            {

                return;
            }

            Transform[] Bones = new Transform[MDL_Header.bone_count];
            PopulateBonesArray(modelObject, Bones);

            foreach (var jiggleBone in MDL_JiggleBones)
            {
                Transform bone = Bones[jiggleBone.bone];
                if (bone == null)
                {

                    continue;
                }

                JiggleBone jiggle = new JiggleBone(bone);
                jiggle.Update(Time.deltaTime, modelObject.transform.position);
            }

            Debug.Log("Jiggle bones applied successfully.");
        }


        private void PopulateBonesArray(GameObject modelObject, Transform[] Bones)
        {
            for (int i = 0; i < MDL_Header.bone_count; i++)
            {
                string boneName = MDL_BoneNames[i];
                Transform boneTransform = modelObject.transform.Find(boneName);

                if (boneTransform != null)
                {
                    Bones[i] = boneTransform;
                }
                else
                {

                }
            }
        }



        private void HandleSequenceEvents(mstudioseqdesc_t sequence, int currentFrame)
        {
            foreach (var evt in sequence.Events)
            {
                if (evt.frame == currentFrame)
                {
                    Debug.Log($"Event triggered: ID {evt.eventID}, Options: {evt.options}");
                    TriggerCustomEvent(evt);
                }
            }
        }


        public static void TriggerCustomEvent(mstudioevent_t evt)
        {
            if (evt.eventID == 1001) // Replace with your event ID
            {
                Debug.Log($"Playing sound: {evt.options}");
            }
            else if (evt.eventID == 1002) // Example: spawn object
            {
                Debug.Log($"Spawning object with parameters: {evt.options}");
            }
        }
        private Transform[] GetModelBones(GameObject modelObject)
        {
            Transform[] bones = new Transform[MDL_Header.bone_count];

            for (int i = 0; i < MDL_Header.bone_count; i++)
            {
                string boneName = MDL_BoneNames[i];
                Transform boneTransform = modelObject.transform.Find(boneName);

                if (boneTransform != null)
                {
                    bones[i] = boneTransform;
                }
                else
                {

                }
            }

            return bones;
        }

        private void ApplyEyeMovement(GameObject modelObject)
        {
            Debug.Log("Applying eye movement...");

            if (Camera.main == null)
            {
                // Debug.LogError (removed)("No Main Camera found in the scene.");
                return;
            }

            Transform[] bones = GetModelBones(modelObject);
            if (bones == null || bones.Length == 0)
            {
                // Debug.LogError (removed)("Bones array is null or empty.");
                return;
            }

            if (MDL_Eyeballs == null || MDL_Eyeballs.Length == 0)
            {
                // Debug.LogError (removed)("MDL_Eyeballs is null or empty.");
                return;
            }

            Vector3 cameraPosition = Camera.main.transform.position;

            foreach (var eye in MDL_Eyeballs)
            {
                if (eye.bone < 0 || eye.bone >= bones.Length)
                {
                    // Debug.LogError (removed)($"Invalid bone index {eye.bone} for eye.");
                    continue;
                }

                Transform boneTransform = bones[eye.bone];
                if (boneTransform == null)
                {
                    // Debug.LogWarning (removed)($"Bone transform at index {eye.bone} is null.");
                    continue;
                }

                Vector3 targetDirection = (cameraPosition - boneTransform.position).normalized;

                Quaternion targetRotation = Quaternion.LookRotation(targetDirection);
                if (!float.IsNaN(targetRotation.x) && !float.IsNaN(targetRotation.y) && !float.IsNaN(targetRotation.z) && !float.IsNaN(targetRotation.w))
                    boneTransform.rotation = Quaternion.Slerp(boneTransform.rotation, targetRotation, 0.1f);
                else
                    Debug.LogError($"Invalid rotation values for bone: {boneTransform.name}");

                Debug.Log($"Eye bone {eye.bone} tracking camera.");
            }
        }





        private int CurrentFrame;

        private Animation AnimationComponent;

        private void InitializeAnimationComponent(GameObject modelObject)
        {
            if (AnimationComponent == null) return; // Added null check

            if (!modelObject.TryGetComponent<Animation>(out AnimationComponent))
            {
                AnimationComponent = modelObject.AddComponent<Animation>();
                Debug.Log("Animation component added to the model.");
            }
        }



        public void PlayAnimation(string animationName)
        {
            if (AnimationComponent == null)
            {
                return;
            }

            if (AnimationComponent != null)
            {
                AnimationComponent.Play(animationName);
                Debug.Log($"Playing animation: {animationName}");
            }
            else
            {
            }
        }

        static int index = 0;

        private Animation[] GetAnimationComponent()
        {
            return AnimComponent;
        }

        private void UpdateCurrentFrame(Animation[] animatorComponent)
        {
            {


            }
        }
        MDL_Event[] mDL_Event;
        [System.Serializable]
        public class SequenceEvent : UnityEvent<mstudioevent_t> { }

        [SerializeField]
        private SequenceEvent onSequenceTriggered = new SequenceEvent();

        public SequenceEvent OnSequenceTriggered => onSequenceTriggered;

        private void HandleFrameEvents(int currentFrame)
        {
            if (MDL_Events == null || MDL_Events.Length == 0)
            {
                return;
            }



            foreach (var mdlEvent in mDL_Event)
            {
                if (MDL_Event.frame == currentFrame)
                {
                    Debug.Log($"Event triggered: {MDL_Event.eventname} on frame {currentFrame}");

                    TriggerEvent(mDL_Event.Length);
                }
            }
        }
        private void LateUpdate()
        {
            UpdateJiggleBones(Time.deltaTime);
        }


        private void Update()
        {
            foreach (var sequence in Sequences)
            {
                if (sequence.seq.numevents > 0)
                {
                    for (int i = 0; i < sequence.seq.numevents; i++)
                    {
                        if (CurrentFrame == eventsCount)
                        {
                            TriggerEvent(i);

                            if (OnSequenceTriggered != null)
                            {
                                OnSequenceTriggered.Invoke(new mstudioevent_t());
                            }



                        }

                        UpdateJiggleBones(Time.deltaTime);
                    }
                }
            }

            {
                UpdateCurrentFrame(GetAnimationComponent());

                HandleFrameEvents(CurrentFrame);
            }

        }


        /// <summary>
        /// Walidacja danych flexów przed przetworzeniem.
        /// </summary>


        /// <summary>
        /// Pobiera nazwę facjalną dla flexa.
        /// </summary>


        /// <summary>
        /// Odczytuje null-terminated string z danych binarnych.
        /// </summary>
        public static string
            ReadNullTerminatedString(byte[] data, int offset, int maxLength = 256)
        {
            int length = 0;
            while (length < maxLength && offset + length < data.Length && data[offset + length] != 0)
                length++;

            return Encoding.UTF8.GetString(data, offset, length);
        }



        public void OnTriggerEnter()
        {

            TriggerEvent(eventsCount);
        }



        public void UpdateJiggleBones(float deltaTime)
        {
            foreach (var jiggleBone in MDL_JiggleBones)
            {
                Transform boneTransform = GetBoneTransform(jiggleBone.bone);
                if (boneTransform != null)
                {
                    JiggleBone jiggle = new JiggleBone(boneTransform);
                    jiggle.Update(deltaTime, transform.position);
                }
            }
        }

        private Transform GetBoneTransform(int boneIndex)
        {
            if (boneIndex < 0 || boneIndex >= MDL_Header.bone_count)
            {
                // Debug.LogError (removed)($"Invalid bone index: {boneIndex}. Ensure it's within the valid range (0 to {MDL_Header.bone_count - 1}).");
                return null;
            }

            if (MDL_BoneNames == null || boneIndex >= MDL_BoneNames.Length)
            {
                // Debug.LogError (removed)("Bone names array is null or does not contain enough elements.");
                return null;
            }

            string boneName = MDL_BoneNames[boneIndex];
            if (string.IsNullOrEmpty(boneName))
            {
                // Debug.LogError (removed)($"Bone name at index {boneIndex} is null or empty.");
                return null;
            }

            Transform boneTransform = transform.Find(boneName);
            if (boneTransform == null)
            {
                // Debug.LogWarning (removed)($"Bone '{boneName}' not found in the hierarchy. Ensure the bone structure matches the MDL file.");
            }

            return boneTransform;
        }


        public static void PopulateKeyframesForAnimation(int numFrames, int numBones, AniInfo aniInfo, mstudiobone_t[] bones)
        {
            for (int frame = 0; frame < numFrames; frame++)
            {
                for (int boneIndex = 0; boneIndex < numBones; boneIndex++)
                {
                    aniInfo.PosX[frame][boneIndex] = new Keyframe(frame / 30.0f, bones[boneIndex].pos.x);
                    aniInfo.PosY[frame][boneIndex] = new Keyframe(frame / 30.0f, bones[boneIndex].pos.y);
                    aniInfo.PosZ[frame][boneIndex] = new Keyframe(frame / 30.0f, bones[boneIndex].pos.z);

                    aniInfo.RotX[frame][boneIndex] = new Keyframe(frame / 30.0f, bones[boneIndex].rot.x);
                    aniInfo.RotY[frame][boneIndex] = new Keyframe(frame / 30.0f, bones[boneIndex].rot.y);
                    aniInfo.RotZ[frame][boneIndex] = new Keyframe(frame / 30.0f, bones[boneIndex].rot.z);
                }
            }
        }
        void PrepareAnimationKeyframes(AniInfo animation, mstudioanimdesc_t studioAnim, int numBones)
        {
            int numFrames = studioAnim.numframes;
            if (numFrames < 2) numFrames += 1;



            for (int frameID = 0; frameID < numFrames; frameID++)
            {

            }
        }




        private void ParseAnimationBones(uReader reader, int animOffset, mstudioanimdesc_t studioAnim, AniInfo aniInfo)
        {
            int boneCount = MDL_Header.bone_count;
            for (int boneIndex = 0; boneIndex < boneCount; boneIndex++)
            {
                var bone = new AnimationBone(bone_, flags, numFrames)
                {
                    Bone = (byte)boneIndex,
                    Flags = (byte)studioAnim.flags,

                };

                aniInfo.AnimationBones.Add(bone);
            }
        }

        private void LoadEventsForSequence(int seqID, uReader FileStream, int sequenceOffset)
        {
            if (MDL_SeqDescriptions == null || seqID < 0 || seqID >= MDL_SeqDescriptions.Length)
            {

                return;
            }

            var sequence = MDL_SeqDescriptions[seqID];
            if (sequence.flags == 0)
            {
                // Debug.LogError (removed)($"Sequence at seqID {seqID} is null");
                return;
            }

            int eventCount = Math.Min(sequence.numevents, MAX_EVENTS_ALLOWED);
            if (eventCount <= 0)
            {
                Debug.Log($"Sequence {seqID} ({sequence.szlabelindex}) has no events.");
                return;
            }

            MDL_Events = new mstudioevent_t[eventCount];

            for (int i = 0; i < eventCount; i++)
            {
                int eventOffset = sequence.eventindex + (i * Marshal.SizeOf(typeof(mstudioevent_t)));
                if (!ValidateOffset(eventOffset, Marshal.SizeOf(typeof(mstudioevent_t)), FileStream.BaseStream.Length))
                {
                    // Debug.LogWarning (removed)($"Invalid offset for event {i} in sequence {seqID}");
                    continue;
                }

                FileStream.ReadTypeFixed(ref MDL_Events[i], Marshal.SizeOf(typeof(mstudioevent_t)), eventOffset);
            }

            Debug.Log($"Loaded {eventCount} events for sequence {seqID} ({sequence.szlabelindex}).");
        }



        public StudioBodyPart[] MDL_Bodyparts;

        public class mstudioseqdescOffsets
        {
            public const int groupsize = 40;    // Offset dla groupsize
            public const int paramindex = 48;  // Offset dla paramindex
            public const int paramstart = 56;  // Offset dla paramstart
            public const int paramend = 64;    // Offset dla paramend
        }// Rozszerz

        public static bool ValidateOffset(int offset, int size, long streamLength)
        {
            if (offset < 0 || offset + size > streamLength)
            {
                return false;
            }
            return true;
        }


        public MDLFile(Stream FileInput, mstudioevent_t[] MDL_Events, bool parseAnims = false, bool parseHitboxes = false)
        {
            using (uReader FileStream = new uReader(FileInput))
            {
                FileStream.ReadTypeFixed(ref MDL_Header, 392);
                if (MDL_Header.id != 0x54534449 || MDL_Header.bone_count == 0) // 'IDST'
                    throw new FileLoadException("File signature does not match 'IDST'");

                Debug.Log($"Loading MDL file: {MDL_Header.Name}, version: {MDL_Header.version}");

                MDL_Events = MDL_Events?.Length > 0 ? MDL_Events : new mstudioevent_t[MDL_Header.eventsindexed];


                LoadEventsForSequence(0, FileStream, 0);



                #region Bones
                #region Bones
                MDL_StudioBones = new mstudiobone_t[MDL_Header.bone_count];
                MDL_BoneNames = new String[MDL_Header.bone_count];
                for (Int32 BoneID = 0; BoneID < MDL_Header.bone_count; BoneID++)
                {
                    Int32 boneOffset = MDL_Header.bone_offset + (216 * BoneID);
                    FileStream.ReadTypeFixed(ref MDL_StudioBones[BoneID], 216, boneOffset);
                    MDL_BoneNames[BoneID] = FileStream.ReadNullTerminatedString(boneOffset + MDL_StudioBones[BoneID].sznameindex);
                }
                #endregion

                #endregion
                {

                    #region Sequence Parsing with Event Handling
                    #region Comprehensive Animation Parsing

                    #region Hitboxes
                    if (parseHitboxes)
                    {
                        MDL_Hitboxsets = new mstudiohitboxset_t[MDL_Header.hitbox_count];
                        Hitboxes = new Hitbox[MDL_Header.hitbox_count][];
                        for (Int32 HitboxsetID = 0; HitboxsetID < MDL_Header.hitbox_count; HitboxsetID++)
                        {
                            Int32 HitboxsetOffset = MDL_Header.hitbox_offset + (12 * HitboxsetID);
                            FileStream.ReadTypeFixed(ref MDL_Hitboxsets[HitboxsetID], 12, HitboxsetOffset);
                            Hitboxes[HitboxsetID] = new Hitbox[MDL_Hitboxsets[HitboxsetID].numhitboxes];

                            for (Int32 HitboxID = 0; HitboxID < MDL_Hitboxsets[HitboxsetID].numhitboxes; HitboxID++)
                            {
                                Int32 HitboxOffset = HitboxsetOffset + (68 * HitboxID) + MDL_Hitboxsets[HitboxsetID].hitboxindex;
                                Hitboxes[HitboxsetID][HitboxID].BBox = new mstudiobbox_t();

                                FileStream.ReadTypeFixed(ref Hitboxes[HitboxsetID][HitboxID].BBox, 68, HitboxOffset);
                            }
                        }
                    }
                    #endregion


                    #region Animation
                    #endregion

                    void InitializeKeyframes(AniInfo animation, int numFrames, int numBones)
                    {
                        animation.PosX = new Keyframe[numFrames][];
                        animation.PosY = new Keyframe[numFrames][];
                        animation.PosZ = new Keyframe[numFrames][];
                        animation.RotX = new Keyframe[numFrames][];
                        animation.RotY = new Keyframe[numFrames][];
                        animation.RotZ = new Keyframe[numFrames][];
                        animation.RotW = new Keyframe[numFrames][];

                        for (int frameID = 0; frameID < numFrames; frameID++)
                        {
                            animation.PosX[frameID] = new Keyframe[numBones];
                            animation.PosY[frameID] = new Keyframe[numBones];
                            animation.PosZ[frameID] = new Keyframe[numBones];
                            animation.RotX[frameID] = new Keyframe[numBones];
                            animation.RotY[frameID] = new Keyframe[numBones];
                            animation.RotZ[frameID] = new Keyframe[numBones];
                            animation.RotW[frameID] = new Keyframe[numBones];
                        }
                    }

                   
                    {
                        

                        if (parseAnims)
                        {
                            // Animations
                            MDL_AniDescriptions = new mstudioanimdesc_t[MDL_Header.localanim_count];
                            Animations = new AniInfo[MDL_Header.localanim_count];

                            for (int AnimID = 0; AnimID < MDL_Header.localanim_count; AnimID++)
                            {
                                int AnimOffset = MDL_Header.localanim_offset + (100 * AnimID);

                                if (!ValidateOffset(AnimOffset, 100, FileStream.BaseStream.Length))
                                    continue;

                                FileStream.ReadTypeFixed(ref MDL_AniDescriptions[AnimID], 100, AnimOffset);
                                mstudioanimdesc_t StudioAnim = MDL_AniDescriptions[AnimID];

                                string StudioAnimName = FileStream.ReadNullTerminatedString(AnimOffset + StudioAnim.sznameindex);
                                Animations[AnimID] = new AniInfo { name = StudioAnimName, studioAnim = StudioAnim };
                                Animations[AnimID].AnimationBones = new List<AnimationBone>();

                                FileStream.BaseStream.Position = AnimOffset;
                                long StartOffset = FileStream.BaseStream.Position;
                                int CurrentOffset = StudioAnim.animindex;
                                short NextOffset;

                                do
                                {
                                    if (StartOffset + CurrentOffset < 0 || StartOffset + CurrentOffset >= FileStream.BaseStream.Length)
                                        break;

                                    FileStream.BaseStream.Position = StartOffset + CurrentOffset;
                                    byte BoneIndex = FileStream.ReadByte();
                                    byte BoneFlag = FileStream.ReadByte();
                                    NextOffset = FileStream.ReadInt16();
                                    CurrentOffset += NextOffset;

                                    AnimationBone AnimatedBone = new AnimationBone(BoneIndex, BoneFlag, StudioAnim.numframes);
                                    AnimatedBone.ReadData(FileStream);
                                    Animations[AnimID].AnimationBones.Add(AnimatedBone);

                                } while (NextOffset != 0);

                                List<AnimationBone> AnimationBones = Animations[AnimID].AnimationBones;
                                int NumBones = MDL_Header.bone_count;
                                int NumFrames = StudioAnim.numframes;

                                bool FramesLess = NumFrames < 2;
                                if (FramesLess) NumFrames += 1;

                                InitializeKeyframes(Animations[AnimID], NumFrames, NumBones);

                                for (int boneID = 0; boneID < NumBones; boneID++)
                                {
                                    AnimationBone AnimBone = AnimationBones.FirstOrDefault(x => x.Bone == boneID);

                                    for (int innerFrameID = 0; innerFrameID < NumFrames; innerFrameID++)
                                    {
                                        float time = innerFrameID / StudioAnim.fps;

                                        mstudiobone_t StudioBone = MDL_StudioBones[boneID];
                                        Vector3 Position = StudioBone.pos;
                                        Vector3 Rotation = StudioBone.rot;

                                        if (AnimBone != null)
                                        {
                                            if ((AnimBone.Flags & STUDIO_ANIM_RAWROT) > 0)
                                                Rotation = MathLibrary.ToEulerAngles(AnimBone.pQuat48);

                                            if ((AnimBone.Flags & STUDIO_ANIM_RAWROT2) > 0)
                                                Rotation = MathLibrary.ToEulerAngles(AnimBone.pQuat64);

                                            if ((AnimBone.Flags & STUDIO_ANIM_RAWPOS) > 0)
                                                Position = AnimBone.pVec48;

                                            if ((AnimBone.Flags & STUDIO_ANIM_ANIMROT) > 0)
                                                Rotation += AnimBone.FrameAngles[(FramesLess && innerFrameID != 0) ? innerFrameID - 1 : innerFrameID].Multiply(StudioBone.rotscale);

                                            if ((AnimBone.Flags & STUDIO_ANIM_ANIMPOS) > 0)
                                                Position += AnimBone.FramePositions[(FramesLess && innerFrameID != 0) ? innerFrameID - 1 : innerFrameID].Multiply(StudioBone.posscale);

                                            if ((AnimBone.Flags & STUDIO_ANIM_DELTA) > 0)
                                            {
                                                Position = Vector3.zero;
                                                Rotation = Vector3.zero;
                                            }
                                        }

                                        ConvertToUnitySpace(StudioBone, ref Position, ref Rotation);
                                        Quaternion quat = MathLibrary.AngleQuaternion(Rotation);

                                        StoreKeyframes(Animations[AnimID], innerFrameID, boneID, time, Position, quat);
                                    }
                                }
                            }

                            ParseSequences(FileStream);

                            // Sequences
                            MDL_SeqDescriptions = new mstudioseqdesc_t[MDL_Header.localseq_count];
                            Sequences = new SeqInfo[MDL_Header.localseq_count];

                            for (Int32 seqID = 0; seqID < MDL_Header.localseq_count; seqID++)
                            {
                                Int32 sequenceOffset = MDL_Header.localseq_offset + (212 * seqID);
                                if (!ValidateOffset(sequenceOffset, 212, FileStream.BaseStream.Length))
                                    continue;

                                FileStream.ReadTypeFixed(ref MDL_SeqDescriptions[seqID], 212, sequenceOffset);
                                mstudioseqdesc_t Sequence = MDL_SeqDescriptions[seqID];

                                Sequences[seqID] = new SeqInfo { name = FileStream.ReadNullTerminatedString(sequenceOffset + Sequence.szlabelindex), seq = Sequence };
                                FileStream.BaseStream.Position = sequenceOffset + Sequence.animindexindex;

                                if (FileStream.BaseStream.Position + (Sequence.groupsize[0] * Sequence.groupsize[1] * 2) <= FileStream.BaseStream.Length)
                                {
                                    var animID = FileStream.ReadShortArray(Sequence.groupsize[0] * Sequence.groupsize[1]);
                                    Sequences[seqID].ani = Animations;
                                }
                            }
                        }
                    }
                        // Helper Methods
                        void ConvertToUnitySpace(mstudiobone_t studioBone, ref Vector3 position, ref Vector3 rotation)
{
    if (studioBone.parent == -1)
        position = MathLibrary.SwapY(position);
    else
        position.x = -position.x;

    position *= uLoader.UnitScale;
    rotation *= Mathf.Rad2Deg;
}

void StoreKeyframes(AniInfo animation, int frameID, int boneID, float time, Vector3 position, Quaternion rotation)
{
    animation.PosX[frameID][boneID] = new Keyframe(time, position.x);
    animation.PosY[frameID][boneID] = new Keyframe(time, position.y);
    animation.PosZ[frameID][boneID] = new Keyframe(time, position.z);
    animation.RotX[frameID][boneID] = new Keyframe(time, rotation.x);
    animation.RotY[frameID][boneID] = new Keyframe(time, rotation.y);
    animation.RotZ[frameID][boneID] = new Keyframe(time, rotation.z);
    animation.RotW[frameID][boneID] = new Keyframe(time, rotation.w);
}




                    Debug.Log("MDL file successfully loaded.");


                    #region Materials
                    MDL_TexturesInfo = new mstudiotexture_t[MDL_Header.texture_count];
                    MDL_Textures = new String[MDL_Header.texture_count];
                    for (Int32 TexID = 0; TexID < MDL_Header.texture_count; TexID++)
                    {
                        Int32 TextureOffset = MDL_Header.texture_offset + (64 * TexID);
                        FileStream.ReadTypeFixed(ref MDL_TexturesInfo[TexID], 64, TextureOffset);
                        MDL_Textures[TexID] = FileStream.ReadNullTerminatedString(TextureOffset + MDL_TexturesInfo[TexID].sznameindex);
                    }

                    Int32[] TDirOffsets = new Int32[MDL_Header.texturedir_count];
                    MDL_TDirectories = new String[MDL_Header.texturedir_count];
                    for (Int32 DirID = 0; DirID < MDL_Header.texturedir_count; DirID++)
                    {
                        FileStream.ReadTypeFixed(ref TDirOffsets[DirID], 4, MDL_Header.texturedir_offset + (4 * DirID));
                        MDL_TDirectories[DirID] = FileStream.ReadNullTerminatedString(TDirOffsets[DirID]);
                    }
                    #endregion



                    #region BodyParts
                    MDL_Bodyparts = new StudioBodyPart[MDL_Header.bodypart_count];
                    for (Int32 BodypartID = 0; BodypartID < MDL_Header.bodypart_count; BodypartID++)
                    {
                        mstudiobodyparts_t BodyPart = new mstudiobodyparts_t();
                        Int32 BodyPartOffset = MDL_Header.bodypart_offset + (16 * BodypartID);
                        FileStream.ReadTypeFixed(ref BodyPart, 16, BodyPartOffset);

                        if (BodyPart.sznameindex != 0)
                            MDL_Bodyparts[BodypartID].Name = FileStream.ReadNullTerminatedString(BodyPartOffset + BodyPart.sznameindex);
                        else
                            MDL_Bodyparts[BodypartID].Name = String.Empty;

                        MDL_Bodyparts[BodypartID].Models = new StudioModel[BodyPart.nummodels];

                        for (Int32 ModelID = 0; ModelID < BodyPart.nummodels; ModelID++)
                        {
                            mstudiomodel_t Model = new mstudiomodel_t();
                            Int64 ModelOffset = BodyPartOffset + (148 * ModelID) + BodyPart.modelindex;
                            FileStream.ReadTypeFixed(ref Model, 148, ModelOffset);

                            MDL_Bodyparts[BodypartID].Models[ModelID].isBlank = (Model.numvertices <= 0 || Model.nummeshes <= 0);
                            MDL_Bodyparts[BodypartID].Models[ModelID].Model = Model;

                            MDL_Bodyparts[BodypartID].Models[ModelID].Meshes = new mstudiomesh_t[Model.nummeshes];
                            for (Int32 MeshID = 0; MeshID < Model.nummeshes; MeshID++)
                            {
                                mstudiomesh_t Mesh = new mstudiomesh_t();
                                Int64 MeshOffset = ModelOffset + (116 * MeshID) + Model.meshindex;
                                FileStream.ReadTypeFixed(ref Mesh, 116, MeshOffset);

                                MDL_Bodyparts[BodypartID].Models[ModelID].Meshes[MeshID] = Mesh;
                            }

                            MDL_Bodyparts[BodypartID].Models[ModelID].IndicesPerLod = new Dictionary<Int32, List<Int32>>[8];

                            for (Int32 i = 0; i < 8; i++)
                                MDL_Bodyparts[BodypartID].Models[ModelID].IndicesPerLod[i] = new Dictionary<Int32, List<Int32>>();

                            MDL_Bodyparts[BodypartID].Models[ModelID].VerticesPerLod = new mstudiovertex_t[8][];
                        }
                    }
                    #endregion
                }
            }
        }

        public static void PlaySound(MDL_Event mdlEvent)
        {
            (string key, string[] value)[] parameters = Array.Empty<(string key, string[] value)>();

            if (TryGetValue(parameters, "soundName", out var soundName))
            {
                Debug.Log($"Playing sound '{soundName}' as part of event '{MDL_Event.eventname}'");

                SoundManager soundManager = GameObject.FindFirstObjectByType<SoundManager>();
                if (soundManager != null)
                {
                    soundManager.PlaySound(soundName);
                    Debug.Log($"Sound '{soundName}' successfully played.");
                }
                else
                {
                    // Debug.LogError (removed)("SoundManager not found.");
                }
            }
            else
            {
                // Debug.LogError (removed)("Sound name not found in event parameters.");
            }
        }
        private static bool TryGetValue((string key, string[] value)[] parameters, string key, out string value)
        {
            var pair = parameters.FirstOrDefault(kv => kv.key == key);
            if (!pair.Equals(default(KeyValuePair<string, string>)))
            {
                value = "value";
                return true;
            }
            value = null;
            return false;
        }

        private void SpawnObject(MDL_Event mdlEvent)
        {
            if (TryGetValue(MDL_Event.parameters, "prefabName", out var prefabName) &&
                TryGetValue(MDL_Event.parameters, "spawnPosition", out var spawnPositionString))
            {
                Debug.Log($"Spawning object '{prefabName}' at position '{spawnPositionString}' as part of event '{MDL_Event.eventname}'");

                if (TryParseVector3(spawnPositionString, out Vector3 spawnPosition))
                {
                    GameObject prefab = ResourceManager.LoadPrefab(prefabName);
                    if (prefab != null)
                    {
                        GameObject.Instantiate(prefab, spawnPosition, Quaternion.identity);
                        Debug.Log($"Object '{prefabName}' successfully spawned at {spawnPosition}.");
                    }
                    else
                    {

                    }
                }
                else
                {

                }
            }
            else
            {

            }
        }


        public static bool TryParseVector3(string vectorString, out Vector3 result)
        {
            result = Vector3.zero;

            vectorString = vectorString.Trim('(', ')');
            string[] components = vectorString.Split(',');

            if (components.Length == 3 &&
                float.TryParse(components[0], out float x) &&
                float.TryParse(components[1], out float y) &&
                float.TryParse(components[2], out float z))
            {
                result = new Vector3(x, y, z);
                return true;
            }

            return false;
        }


        public void SetIndices(Int32 BodypartID, Int32 ModelID, Int32 LODID, Int32 MeshID, List<Int32> Indices)
        {
            MDL_Bodyparts[BodypartID].Models[ModelID].IndicesPerLod[LODID].Add(MeshID, Indices);
        }

        public void SetVertices(Int32 BodypartID, Int32 ModelID, Int32 LODID, Int32 TotalVerts, Int32 StartIndex, mstudiovertex_t[] Vertexes)
        {
            MDL_Bodyparts[BodypartID].Models[ModelID].VerticesPerLod[LODID] = new mstudiovertex_t[TotalVerts];
            Array.Copy(Vertexes, StartIndex, MDL_Bodyparts[BodypartID].Models[ModelID].VerticesPerLod[LODID], 0, TotalVerts);
        }

        public Boolean BuildMesh = true;

        public struct FlexVertex
        {
            public int VertexIndex;           // Index of the vertex this flex applies to
            public Vector3 PositionDelta;     // Change in position for the vertex
            public Vector3 NormalDelta;       // Change in normal for the vertex
            public Vector3 TangentDelta;      // Change in tangent for the vertex

            public static FlexVertex FromReader(BinaryReader reader)
            {
                return new FlexVertex
                {
                    VertexIndex = reader.ReadInt32(),
                    PositionDelta = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle()),
                    NormalDelta = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle()),
                    TangentDelta = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle())
                };
            }
        }


        public FlexVertex[] FlexVertices;
        public byte[] mdldata;
        public byte bone_ { get; private set; }
        public byte flags { get; private set; }
        public int numFrames { get; private set; }
        public Transform transform { get; private set; }
        public GameObject go { get; private set; }
        public Animation animation { get; private set; }
        public byte[] mdlData { get; private set; }

        public Transform BuildModel(Boolean GenerateUV2 = false)
        {
            GameObject ModelObject = new GameObject(MDL_Header.Name);

            #region Bones
            Transform[] Bones = new Transform[MDL_Header.bone_count];
            Dictionary<Int32, String> bonePathDict = new Dictionary<Int32, String>();
            for (Int32 boneID = 0; boneID < MDL_Header.bone_count; boneID++)
            {
                GameObject BoneObject = new GameObject(MDL_BoneNames[boneID]);

                Bones[boneID] = BoneObject.transform;//MDL_Bones.Add(BoneObject.transform);

                Vector3 pos = MDL_StudioBones[boneID].pos * uLoader.UnitScale;
                Vector3 rot = MDL_StudioBones[boneID].rot * Mathf.Rad2Deg;

                //Invert x for convert right-handed to left-handed
                pos.x = -pos.x;

                if (MDL_StudioBones[boneID].parent >= 0)
                {
                    Bones[boneID].parent = Bones[MDL_StudioBones[boneID].parent];
                }
                else
                {
                    //Swap Z & Y and invert Y (ex: X Z -Y)
                    //only for parents, cuz parents used different order vectors
                    float temp = pos.y;
                    pos.y = pos.z;
                    pos.z = -temp;

                    Bones[boneID].parent = ModelObject.transform;
                }

                bonePathDict.Add(boneID, Bones[boneID].GetTransformPath(ModelObject.transform));

                Bones[boneID].localPosition = pos;
                //Bones[i].localRotation = MDL_StudioBones[i].quat;

                if (MDL_StudioBones[boneID].parent == -1)
                {
                    //Fix up parents
                    Bones[boneID].localRotation = Quaternion.Euler(-90, 90, -90) * MathLibrary.AngleQuaternion(rot);
                }
                
                    Quaternion safeRotation = MathLibrary.AngleQuaternion(rot);
                if (!float.IsNaN(safeRotation.x) && !float.IsNaN(safeRotation.y) && !float.IsNaN(safeRotation.z) && !float.IsNaN(safeRotation.w))
                    Bones[boneID].localRotation = safeRotation;
                else
                    Debug.LogError($"Invalid local rotation values for bone ID {boneID}");
            }
            if (uLoader.DrawArmature)
            {
                MDLArmatureInfo DebugArmature = ModelObject.AddComponent<MDLArmatureInfo>();
                DebugArmature.boneNodes = Bones;
            }
            #endregion

            #region Hitboxes
            if (MDL_Hitboxsets != null)
            {
                for (Int32 HitboxsetID = 0; HitboxsetID < MDL_Header.hitbox_count; HitboxsetID++)
                {
                    for (Int32 HitboxID = 0; HitboxID < MDL_Hitboxsets[HitboxsetID].numhitboxes; HitboxID++)
                    {
                        mstudiobbox_t Hitbox = Hitboxes[HitboxsetID][HitboxID].BBox;
                        BoxCollider BBox = new GameObject(String.Format("Hitbox_{0}", Bones[Hitbox.bone].name)).AddComponent<BoxCollider>();

                        BBox.size = MathLibrary.NegateX(Hitbox.bbmax - Hitbox.bbmin) * uLoader.UnitScale;
                        BBox.center = (MathLibrary.NegateX(Hitbox.bbmax + Hitbox.bbmin) / 2) * uLoader.UnitScale;

                        BBox.transform.parent = Bones[Hitbox.bone];
                        BBox.transform.localPosition = Vector3.zero;
                        BBox.transform.localRotation = Quaternion.identity;

                    }
                }
            }
            #endregion

            if (BuildMesh)
            {
                for (Int32 BodypartID = 0; BodypartID < MDL_Header.bodypart_count; BodypartID++)
                {
                    StudioBodyPart BodyPart = MDL_Bodyparts[BodypartID];

                    for (Int32 ModelID = 0; ModelID < BodyPart.Models.Length; ModelID++)
                    {
                        StudioModel Model = BodyPart.Models[ModelID];

                        if (Model.isBlank)
                            continue;

                        mstudiovertex_t[] Vertexes = Model.VerticesPerLod[0];

                        BoneWeight[] BoneWeight = new BoneWeight[Vertexes.Length];
                        Vector3[] Vertices = new Vector3[Vertexes.Length];
                        Vector3[] Normals = new Vector3[Vertexes.Length];
                        Vector2[] UvBuffer = new Vector2[Vertexes.Length];

                        for (Int32 i = 0; i < Vertexes.Length; i++)
                        {
                            Vertices[i] = MathLibrary.SwapZY(Vertexes[i].m_vecPosition * uLoader.UnitScale);
                            Normals[i] = MathLibrary.SwapZY(Vertexes[i].m_vecNormal);

                            Vector2 UV = Vertexes[i].m_vecTexCoord;
                            if (uLoader.SaveAssetsToUnity && uLoader.ExportTextureAsPNG)
                                UV.y = -UV.y;

                            UvBuffer[i] = UV;
                            BoneWeight[i] = GetBoneWeight(Vertexes[i].m_BoneWeights);
                        }
                        #endregion

                        #region LOD Support
                        Boolean DetailModeEnabled =
                            uLoader.DetailMode == DetailMode.Lowest ||
                            uLoader.DetailMode == DetailMode.Low ||
                            uLoader.DetailMode == DetailMode.Medium ||
                            uLoader.DetailMode == DetailMode.High;

                        Boolean LODExist = uLoader.EnableLODParsing && !DetailModeEnabled && Model.NumLODs > 1;
                        Transform FirstLODObject = null;
                        LODGroup LODGroup = null;
                        LOD[] LODs = null;
                        Single MaxSwitchPoint = 100;
                        Int32 StartLODIndex = 0;

                        if (LODExist)
                        {
                            LODs = new LOD[Model.NumLODs];

                            for (Int32 LODID = 1; LODID < 3; LODID++)
                            {
                                Int32 LastID = Model.NumLODs - LODID;
                                ModelLODHeader_t LOD = Model.LODData[LastID];

                                if (LOD.switchPoint != -1)
                                {
                                    if (LOD.switchPoint > 0)
                                        MaxSwitchPoint = LOD.switchPoint;

                                    if (LODID == 2 || LOD.switchPoint == 0)
                                    {
                                        MaxSwitchPoint += MaxSwitchPoint * uLoader.NegativeAddLODPrecent;
                                        Model.LODData[LOD.switchPoint == 0 ? LastID : LastID + 1].switchPoint = MaxSwitchPoint;
                                    }

                                    MaxSwitchPoint += uLoader.ThresholdMaxSwitch;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            if (!uLoader.EnableLODParsing)
                                Model.NumLODs = 1;
                        }

                        if (uLoader.EnableLODParsing && DetailModeEnabled)
                        {
                            StartLODIndex =
                                uLoader.DetailMode == DetailMode.Lowest ? (Model.NumLODs - 1) :
                                uLoader.DetailMode == DetailMode.Low ? (Int32)(Model.NumLODs / 1.5f) :
                                uLoader.DetailMode == DetailMode.Medium ? (Model.NumLODs / 2) : (Int32)(Model.NumLODs / 2.5f);
                        }
                        #endregion

                        #region Build Meshes
                        for (Int32 LODID = StartLODIndex; LODID < Model.NumLODs; LODID++)
                        {
                            #region TODO: Uncomment after find way to strip unused vertexes for lod's (VTXStripGroup / VTXStrip)
                            /*mstudiovertex_t[] Vertexes = Model.VerticesPerLod[LODID];

                            BoneWeight[] BoneWeight = new BoneWeight[Vertexes.Length];
                            Vector3[] Vertices = new Vector3[Vertexes.Length];
                            Vector3[] Normals = new Vector3[Vertexes.Length];
                            Vector2[] UvBuffer = new Vector2[Vertexes.Length];

                            for (Int32 i = 0; i < Vertexes.Length; i++)
                            {
                                Vertices[i] = MathLibrary.SwapZY(Vertexes[i].m_vecPosition * uLoader.UnitScale);
                                Normals[i] = MathLibrary.SwapZY(Vertexes[i].m_vecNormal);

                                Vector2 UV = Vertexes[i].m_vecTexCoord;
                                if (uLoader.SaveAssetsToUnity && uLoader.ExportTextureAsPNG)
                                    UV.y = -UV.y;

                                UvBuffer[i] = UV;
                                BoneWeight[i] = GetBoneWeight(Vertexes[i].m_BoneWeights);
                            }*/
                            #endregion

                            #region LOD
                            ModelLODHeader_t ModelLOD = Model.LODData[LODID];

                            if (LODExist)
                            {
                                if (ModelLOD.switchPoint == 0)
                                    ModelLOD.switchPoint = MaxSwitchPoint;
                                else
                                    ModelLOD.switchPoint = MaxSwitchPoint - ModelLOD.switchPoint;

                                ModelLOD.switchPoint -= ModelLOD.switchPoint * uLoader.SubstractLODPrecent;
                            }
                            #endregion

                            #region Mesh
                            GameObject MeshObject = new GameObject(Model.Model.Name);
                            MeshObject.name += "_vLOD" + LODID;
                            MeshObject.transform.parent = ModelObject.transform;

                            Mesh Mesh = new Mesh
                            {
                                name = MeshObject.name,

                                subMeshCount = Model.Model.nummeshes,
                                vertices = Vertices
                            };
                            if (Mesh.vertexCount <= 0)
                            {
                                continue;
                            }

                            Mesh.normals = Normals;
                            Mesh.uv = UvBuffer;
                            #endregion

                            #region Renderers
                            Renderer Renderer;
                            if (!MDL_Header.flags.HasFlag(StudioHDRFlags.STUDIOHDR_FLAGS_STATIC_PROP))
                            {
                                SkinnedMeshRenderer SkinnedRenderer = MeshObject.AddComponent<SkinnedMeshRenderer>();
                                Renderer = SkinnedRenderer;
                                Matrix4x4[] BindPoses = new Matrix4x4[Bones.Length];

                                for (Int32 i = 0; i < BindPoses.Length; i++)
                                    BindPoses[i] = Bones[i].worldToLocalMatrix * MeshObject.transform.localToWorldMatrix;

                                Mesh.boneWeights = BoneWeight;
                                Mesh.bindposes = BindPoses;

                                SkinnedRenderer.sharedMesh = Mesh;

                                SkinnedRenderer.bones = Bones;
                                SkinnedRenderer.updateWhenOffscreen = true;

                            }
                            else
                            {
                                MeshFilter MeshFilter = MeshObject.AddComponent<MeshFilter>();
                                Renderer = MeshObject.AddComponent<MeshRenderer>();
                                MeshFilter.sharedMesh = Mesh;
                            }

                            Renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.TwoSided;
                            #endregion

                            #region Debug Stuff
#if UNITY_EDITOR
                            DebugMaterial DebugMat = null;
                            if (uLoader.DebugMaterials)
                                DebugMat = MeshObject.AddComponent<DebugMaterial>();
#endif
#endregion

                            #region Triangles and Materials
                            Material[] Materials = new Material[Mesh.subMeshCount];

                            for (Int32 MeshID = 0; MeshID < Model.Model.nummeshes; MeshID++)
                            {
                                Mesh.SetTriangles(Model.IndicesPerLod[LODID][MeshID], MeshID);

                                String MaterialPath;
                                Int32 LastDirID = MDL_TDirectories.Length - 1;
                                for (Int32 DirID = 0; DirID < MDL_TDirectories.Length; DirID++)
                                {
                                    MaterialPath = MDL_TDirectories[DirID] + MDL_Textures[Model.Meshes[MeshID].material];

                                    if (uResourceManager.ContainsFile(MaterialPath, uResourceManager.MaterialsSubFolder, uResourceManager.MaterialsExtension[0]))
                                    {
                                        VMTFile VMT = uResourceManager.LoadMaterial(MaterialPath);

                                        #region Debug Stuff
#if UNITY_EDITOR
                                        if (uLoader.DebugMaterials)
                                            DebugMat.Init(VMT);
#endif
#endregion

                                        Materials[MeshID] = VMT.Material;
                                        break;
                                    }
                                    else if (DirID == LastDirID)
                                        Materials[MeshID] = uResourceManager.LoadMaterial(String.Empty).Material;
                                }
                            }

                            Renderer.sharedMaterials = Materials;
                            #endregion


                            #endregion

                            #region UV2
#if UNITY_EDITOR
                            if (GenerateUV2)
                            {
                                UnityEditor.SerializedObject so = new UnityEditor.SerializedObject(Renderer);
                                so.FindProperty("m_ScaleInLightmap").floatValue = uLoader.ModelsLightmapSize;
                                so.ApplyModifiedProperties();

                                MeshObject.isStatic = GenerateUV2;
                                uResourceManager.UV2GenerateCache.Add(Mesh);
                            }
#endif
#endregion

                            #region Set LOD's
                            if (LODExist)
                            {
                                if (LODID == 0)
                                {
                                    LODGroup = MeshObject.AddComponent<LODGroup>();
                                    FirstLODObject = MeshObject.transform;
                                }
                                else if (FirstLODObject != null)
                                    MeshObject.transform.parent = FirstLODObject;

                                LODs[LODID] = new LOD(ModelLOD.switchPoint / MaxSwitchPoint, new Renderer[] { Renderer });
                            }

                            if (uLoader.EnableLODParsing && DetailModeEnabled)
                                break;
                            #endregion
                        }//lod's per model

                        if (LODGroup != null)
                            LODGroup.SetLODs(LODs);
#endregion
                    }//models in bodypart
                }//Bodypart
            }

            ApplyJiggleBones(ModelObject);

            #region Animations
            if (MDL_SeqDescriptions != null)
            {
                var AnimationComponent = ModelObject.AddComponent<Animation>();
                for (Int32 seqID = 0; seqID < MDL_SeqDescriptions.Length; seqID++)
                {
                    SeqInfo Sequence = Sequences[seqID];
                    for (int animIndex = 0; animIndex < Sequence.ani.Length; animIndex++)
                    {

                        AniInfo Animation = Sequence.ani[animIndex];



                        //Creating "AnimationCurve" for animation "paths" (aka frames where stored position (XYZ) & rotation (XYZW))
                        AnimationCurve[] posX = new AnimationCurve[MDL_Header.bone_count];    //X
                        AnimationCurve[] posY = new AnimationCurve[MDL_Header.bone_count];    //Y
                        AnimationCurve[] posZ = new AnimationCurve[MDL_Header.bone_count];    //Z

                        AnimationCurve[] rotX = new AnimationCurve[MDL_Header.bone_count];    //X
                        AnimationCurve[] rotY = new AnimationCurve[MDL_Header.bone_count];    //Y
                        AnimationCurve[] rotZ = new AnimationCurve[MDL_Header.bone_count];    //Z
                        AnimationCurve[] rotW = new AnimationCurve[MDL_Header.bone_count];    //W

                        //Fill "AnimationCurve" arrays
                        for (Int32 boneIndex = 0; boneIndex < MDL_Header.bone_count; boneIndex++)
                        {
                            posX[boneIndex] = new AnimationCurve();
                            posY[boneIndex] = new AnimationCurve();
                            posZ[boneIndex] = new AnimationCurve();

                            rotX[boneIndex] = new AnimationCurve();
                            rotY[boneIndex] = new AnimationCurve();
                            rotZ[boneIndex] = new AnimationCurve();
                            rotW[boneIndex] = new AnimationCurve();
                        }

                        Int32 numFrames = Animation.studioAnim.numframes;

                        //Used to avoid "Assertion failed" key count in Unity (if frames less than 2)
                        if (numFrames < 2)
                            numFrames += 1;

                        //Create animation clip
                        AnimationClip clip = new AnimationClip();
                        //Make it for legacy animation system (for now, but it possible to rework for Mecanim)
                        clip.legacy = true;
                        //Set animation clip name
                        clip.name = Animation.name;

                        //To avoid problems with "obfuscators" / "protectors" for models, make sure if model have name in sequence
                        if (String.IsNullOrEmpty(clip.name))
                            clip.name = "(empty)" + seqID;

                        for (Int32 frameIndex = 0; frameIndex < numFrames; frameIndex++)
                        {
                            //Get current frame from blend (meaning from "Animation") by index
                            //AnimationFrame frame = Animation.Frames[frameIndex];

                            //Set keys (position / rotation) from current frame
                            for (Int32 boneIndex = 0; boneIndex < Bones.Length; boneIndex++)
                            {
                                posX[boneIndex].AddKey(Animation.PosX[frameIndex][boneIndex]);
                                posY[boneIndex].AddKey(Animation.PosY[frameIndex][boneIndex]);
                                posZ[boneIndex].AddKey(Animation.PosZ[frameIndex][boneIndex]);

                                rotX[boneIndex].AddKey(Animation.RotX[frameIndex][boneIndex]);
                                rotY[boneIndex].AddKey(Animation.RotY[frameIndex][boneIndex]);
                                rotZ[boneIndex].AddKey(Animation.RotZ[frameIndex][boneIndex]);
                                rotW[boneIndex].AddKey(Animation.RotW[frameIndex][boneIndex]);

                                //Set default pose from the first animation
                                if (seqID == 0 && frameIndex == 0)
                                {
                                    Bones[boneIndex].localPosition = new Vector3
                                    (
                                        Animation.PosX[0][boneIndex].value,
                                        Animation.PosY[0][boneIndex].value,
                                        Animation.PosZ[0][boneIndex].value
                                    );

                                    Bones[boneIndex].localRotation = new Quaternion
                                    (
                                        Animation.RotX[0][boneIndex].value,
                                        Animation.RotY[0][boneIndex].value,
                                        Animation.RotZ[0][boneIndex].value,
                                        Animation.RotW[0][boneIndex].value
                                    );
                                }
                            }
                        }

                        //Apply animation paths (Position / Rotation) to clip
                        for (Int32 boneIndex = 0; boneIndex < MDL_Header.bone_count; boneIndex++)
                        {
                            clip.SetCurve(bonePathDict[boneIndex], typeof(Transform), "localPosition.x", posX[boneIndex]);
                            clip.SetCurve(bonePathDict[boneIndex], typeof(Transform), "localPosition.y", posY[boneIndex]);
                            clip.SetCurve(bonePathDict[boneIndex], typeof(Transform), "localPosition.z", posZ[boneIndex]);

                            clip.SetCurve(bonePathDict[boneIndex], typeof(Transform), "localRotation.x", rotX[boneIndex]);
                            clip.SetCurve(bonePathDict[boneIndex], typeof(Transform), "localRotation.y", rotY[boneIndex]);
                            clip.SetCurve(bonePathDict[boneIndex], typeof(Transform), "localRotation.z", rotZ[boneIndex]);
                            clip.SetCurve(bonePathDict[boneIndex], typeof(Transform), "localRotation.w", rotW[boneIndex]);
                        }

                        if (Animation.studioAnim.fps > 0.0f)
                            clip.frameRate = Animation.studioAnim.fps;

                        //This ensures a smooth interpolation (corrects the problem of "jitter" after 180~270 degrees rotation path)
                        //can be "comment" if have idea how to replace this
                        clip.EnsureQuaternionContinuity();
                        AnimationComponent.AddClip(clip, clip.name);
                    }

                    #endregion

                }


                InitializeAnimationComponent(ModelObject);

                ProcessModel(ModelObject);

                ProcessFlexes(ModelObject);
                ValidateAndAssignAnimations(ModelObject);

                ApplyEyeMovement(ModelObject);







            }


            if (MDL_Header.flags.HasFlag(StudioHDRFlags.STUDIOHDR_FLAGS_STATIC_PROP))
                ModelObject.transform.eulerAngles = new Vector3(0, 90, 0);

            return ModelObject.transform;
        }
        public enum EventType { PlaySound, SpawnObject, StartAnimation }

        /// <summary>
        /// Validates whether the given offset is within the bounds of the stream.
        /// </summary>
        /// <param name="offset">Offset to validate.</param>
        /// <param name="stream">Stream to validate against.</param>
        /// <param name="errorMessage">Custom error message in case of invalid offset.</param>
        /// <param name="errorMessage">Custom error message in case of invalid offset.</param>
        private void TriggerEvent(int eventIndex)
        {
            if (MDL_Events == null || eventIndex < 0 || eventIndex >= MDL_Events.Length)
            {
                return;
            }

            MDL_Event mdlEvent = new MDL_Event("eventname", 1);
            Debug.Log($"Event triggered: {MDL_Event.eventname} on frame {MDL_Event.frame}");

            if (Enum.TryParse(MDL_Event.eventname, ignoreCase: true, out EventType eventType))
            {
                switch (eventType)
                {
                    case EventType.PlaySound:
                        PlaySound(mdlEvent);
                        break;

                    case EventType.SpawnObject:
                        SpawnObject(mdlEvent);
                        break;

                    case EventType.StartAnimation:
                        StartAnimation(mdlEvent);
                        break;

                    default:
                        break;
                }
            }
            else
            {
            }
        }
        Animation animator;
        private int eventsCount;
#if UNITY_EDITOR


#endif
        private AnimationCurve blendCurve;

        private void StartAnimation(MDL_Event mdlEvent)
        {
            (string key, string[] value)[] parameters = Array.Empty<(string key, string[] value)>();
            if (TryGetValue(parameters, "animationName", out var animationName))
            {
                Debug.Log($"Starting animation '{animationName}' as part of event '{MDL_Event.eventname}'");


                if (animator == null && go.TryGetComponent<Animation>(out animator))
                    animator.Play(animationName);






            }


        }

        private void ValidateAndAssignAnimations(GameObject modelObject)
        {
            if (!modelObject.TryGetComponent<Animation>(out var animator))
            {
                // Debug.LogWarning (removed)("Animation component is missing. Animations cannot be assigned.");
                return;
            }

            if (Sequences == null || Sequences.Length == 0)
            {
                // Debug.LogWarning (removed)("No sequences found to assign to Animation.");
                return;
            }


        }
        private void ProcessFlexes(GameObject modelObject)
        {
            Debug.Log("Processing flexes...");

            SkinnedMeshRenderer skinnedMeshRenderer = modelObject.GetComponent<SkinnedMeshRenderer>();
            if (skinnedMeshRenderer == null || skinnedMeshRenderer.sharedMesh == null)
            {

                return;
            }

            Mesh mesh = skinnedMeshRenderer.sharedMesh;

            if (MDL_FlexDescs == null || MDL_Flexes == null || FlexVertices == null)
            {

                return;
            }

            Debug.Log($"Adding blendshapes for {MDL_FlexDescs.Length} flexes...");
            AddBlendshapes(mesh, MDL_FlexDescs, MDL_Flexes, FlexVertices);
            Debug.Log("Flexes processed successfully.");
        }

        private void AddBlendshapes(Mesh mesh, mstudioflexdesc_t[] flexDescs, mstudioflex_t[] flexes, FlexVertex[] flexVertices)
        {
            HashSet<string> blendshapeNames = new HashSet<string>();

            Vector3[] deltaVertices = new Vector3[mesh.vertexCount];
            Vector3[] deltaNormals = new Vector3[mesh.vertexCount];
            Vector3[] deltaTangents = new Vector3[mesh.vertexCount];

            foreach (var flex in flexes)
            {
                if (!ValidateFlexData(flex, mesh.vertexCount, flexVertices.Length))
                {

                    continue;
                }

                Array.Clear(deltaVertices, 0, deltaVertices.Length);
                Array.Clear(deltaNormals, 0, deltaNormals.Length);

                for (int i = 0; i < flex.numVerts; i++)
                {
                    int vertexIndex = flex.vertexOffset + i;
                    if (vertexIndex >= flexVertices.Length) continue;

                    var flexVertex = flexVertices[vertexIndex];
                    if (flexVertex.VertexIndex >= deltaVertices.Length) continue;

                    deltaVertices[flexVertex.VertexIndex] = flexVertex.PositionDelta;
                    deltaNormals[flexVertex.VertexIndex] = flexVertex.NormalDelta;
                }

                string flexName = flexDescs[flex.flexDesc].pszFACS(mdlData, 0) ?? $"BlendShape_{flex.flexDesc}";
                if (!blendshapeNames.Add(flexName))
                {

                    continue;
                }

                mesh.AddBlendShapeFrame(flexName, 100f, deltaVertices, deltaNormals, deltaTangents);
                Debug.Log($"Blendshape added: {flexName}");
            }

            mesh.RecalculateBounds();
            Debug.Log("Blendshape creation completed.");
        }

        private bool ValidateFlexData(mstudioflex_t flex, int vertexCount, int flexVertexLength)
        {
            return !(flex.numVerts > vertexCount || flex.vertexOffset + flex.numVerts > flexVertexLength);
        }

        private void ParseSequences(uReader fileStream)
        {
            Debug.Log("Parsing sequences...");

            if (MDL_Header.localseq_count > 0)
            {
                Sequences = new SeqInfo[MDL_Header.localseq_count];
            }
            else
            {
                // Debug.LogError (removed)("MDL_Header.localseq_count is zero or invalid.");
                return;
            }

            for (int seqID = 0; seqID < MDL_Header.localseq_count; seqID++)
            {
                int seqOffset = MDL_Header.localseq_offset + (212 * seqID);

                mstudioseqdesc_t sequence = new mstudioseqdesc_t();
                fileStream.ReadTypeFixed(ref sequence, 212, seqOffset);

                if (sequence.groupsize == null || sequence.groupsize.Length < 2)
                {
                    sequence.groupsize = new int[] { 1, 1 };
                }

                Sequences[seqID] = new SeqInfo
                {
                    name = fileStream.ReadNullTerminatedString(seqOffset + sequence.szlabelindex),
                    seq = sequence,
                    ani = new AniInfo[index] // Initialize with an empty array
                };

                Debug.Log($"Sequence loaded: {Sequences[seqID].name}");

                ParseAnimationsForSequence(fileStream, sequence, Sequences[seqID]);
            }
        }
        private void ParseAnimationsForSequence(uReader fileStream, mstudioseqdesc_t sequence, SeqInfo sequenceInfo)
        {
            if (sequence.groupsize == null || sequence.groupsize.Length < 2)
            {
                sequence.groupsize = new int[] { 1, 1 }; // Default to 1x1 if uninitialized
            }

            int animGroupSize = sequence.groupsize[0] * sequence.groupsize[1];
            if (animGroupSize <= 0) return;

            byte[] animIndices = new byte[animGroupSize];

            if (sequence.animindexindex < 0 || sequence.animindexindex >= fileStream.BaseStream.Length)
            {
                return;
            }

            fileStream.BaseStream.Position = sequence.animindexindex;
            fileStream.Read(animIndices, 0, animIndices.Length);


            foreach (var animIndex in animIndices)
            {
                if (Animations == null || animIndex < 0 || animIndex >= Animations.Length)
                {
                    continue;
                }

                AniInfo aniInfo = Animations[animIndex];
                if (aniInfo == null)
                {
                    continue;
                }


            }

        }

        public class SMDLoader
        {
            public static Dictionary<int, Dictionary<string, BoneFrameData>> BoneFrameDataPerFrame = new Dictionary<int, Dictionary<string, BoneFrameData>>();

            public class BoneFrameData
            {
                public Vector3 Position;
                public Quaternion Rotation;

                public BoneFrameData(Vector3 position, Quaternion rotation)
                {
                    Position = position;
                    Rotation = rotation;
                }
            }



            public static void LoadSMDAnimations(string smdFilePath)
            {
                StreamReader reader = new(Stream.Null);
                int currentFrame = -1;
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (line.StartsWith("time"))
                    {
                        currentFrame = int.Parse(line.Split(' ')[1]);
                        BoneFrameDataPerFrame[currentFrame] = new Dictionary<string, BoneFrameData>();
                    }
                    else
                    {
                        string[] parts = line.Split(' ');
                        if (parts.Length >= 7)
                        {
                            string boneName = parts[0];
                            Vector3 position = new Vector3(float.Parse(parts[1]), float.Parse(parts[2]), float.Parse(parts[3]));
                            Quaternion rotation = new Quaternion(float.Parse(parts[4]), float.Parse(parts[5]), float.Parse(parts[6]), float.Parse(parts[7]));
                            BoneFrameDataPerFrame[currentFrame][boneName] = new BoneFrameData(position, rotation);
                        }
                    }
                }
            }

        }
        public static void Use_LoadSMDAnimations()
        {
            SMDLoader.LoadSMDAnimations("models");

            Use_LoadSMDAnimations();
        }
        [Serializable]


        public class MDL_Event
        {
            public static string eventname;

            public static int frame;

            public static (string key, string[] value)[] parameters;


            public MDL_Event(string eventname, int frame, (string key, string[] value)[] parameters = null)
            {

                MDL_Event.eventname = eventname;
                MDL_Event.frame = frame;
                MDL_Event.parameters = parameters ?? Array.Empty<(string, string[])>();
            }

            /// <summary>
            /// Add or update a parameter in the event.
            /// </summary>
            public static void AddParameter(string key, string value)
            {
                int index = Array.FindIndex(parameters, p => p.key == key);
                if (index >= 0)
                {
                    Array.Resize(ref parameters[index].value, parameters[index].value.Length + 1);
                    parameters[index].value[^1] = value;
                    Debug.Log($"Updated parameter '{key}' with value '{value}' for event '{eventname}'.");
                }
                else
                {
                    Array.Resize(ref parameters, parameters.Length + 1);
                    parameters[^1] = (key, new[] { value });
                    Debug.Log($"Added parameter '{key}' with value '{value}' for event '{eventname}'.");
                }
            }

            /// <summary>
            /// Get a parameter value by key.
            /// </summary>
            public static bool TryGetValue((string key, string[] value)[] parameters, string key, out string[] value)
            {
                int index = Array.FindIndex(parameters, p => p.key == key);
                if (index >= 0)
                {
                    value = parameters[index].value;
                    return true;
                }

                value = null;
                return false;
            }

            /// <summary>
            /// Remove a parameter from the event.
            /// </summary>
            public static bool RemoveParameter(string key)
            {
                int index = Array.FindIndex(parameters, p => p.key == key);
                if (index >= 0)
                {
                    for (int i = index; i < parameters.Length - 1; i++)
                    {
                        parameters[i] = parameters[i + 1];
                    }
                    Array.Resize(ref parameters, parameters.Length - 1);
                    Debug.Log($"Removed parameter '{key}' from event '{eventname}'.");
                    return true;
                }

                return false;
            }



            /// <summary>
            /// Remove a parameter from the event.
            /// </summary>
            /// 



            /// <summary>
            /// Print all event details for debugging.
            /// </summary>

        }

        private void InitializeMethods()
        {
            Use_HandleSequenceEvents();

            Use_UpdateProceduralBones();


            Use_AnimationClipCreator();


            JiggleBone.Use_UpdateWindSettings();
            Use_LoadSMDAnimations();
            Use_CreateAnimationClip();
            Use_ProcessFile();
        }

        public static void Use_CreateAnimationClip()
        {
            AnimationClipCreator.CreateAnimationClip(new SMDLoader(), new Transform[0], "", 1);
            Use_CreateAnimationClip();
        }

        public class AnimationClipCreator
        {
            public static AnimationClip CreateAnimationClip(SMDLoader smdLoader, Transform[] boneTransforms, string clipName, float frameRate = 24f)
            {
                AnimationClip clip = new AnimationClip
                {
                    name = clipName,
                    frameRate = frameRate,
                    legacy = true
                };

                foreach (var frameEntry in SMDLoader.BoneFrameDataPerFrame)
                {
                    int frame = frameEntry.Key;
                    float time = frame / frameRate;

                    foreach (var boneData in frameEntry.Value)
                    {
                        string boneName = boneData.Key;
                        SMDLoader.BoneFrameData frameData = boneData.Value;

                        clip.SetCurve(boneName, typeof(Transform), "localPosition.x", CreateCurve(boneTransforms, boneName, time, frameData.Position.x));
                        clip.SetCurve(boneName, typeof(Transform), "localPosition.y", CreateCurve(boneTransforms, boneName, time, frameData.Position.y));
                        clip.SetCurve(boneName, typeof(Transform), "localPosition.z", CreateCurve(boneTransforms, boneName, time, frameData.Position.z));

                        clip.SetCurve(boneName, typeof(Transform), "localRotation.x", CreateCurve(boneTransforms, boneName, time, frameData.Rotation.x));
                        clip.SetCurve(boneName, typeof(Transform), "localRotation.y", CreateCurve(boneTransforms, boneName, time, frameData.Rotation.y));
                        clip.SetCurve(boneName, typeof(Transform), "localRotation.z", CreateCurve(boneTransforms, boneName, time, frameData.Rotation.z));
                        clip.SetCurve(boneName, typeof(Transform), "localRotation.w", CreateCurve(boneTransforms, boneName, time, frameData.Rotation.w));
                    }
                }

                clip.EnsureQuaternionContinuity();
                return clip;
            }
        }


        private void Use_HandleSequenceEvents()
        {
            HandleSequenceEvents(sequence, 0);
        }



        #region Misc Stuff

        #region Misc Stuff
        static String HitTagType(Int32 typeHit)
        {
            String returnType;
            switch (typeHit)
            {
                case 1: // - Used for human NPC heads and to define where the player sits on the vehicle.mdl, appears Red in HLMV
                    returnType = "Head";
                    break;

                case 2: // - Used for human NPC midsection and chest, appears Green in HLMV
                    returnType = "Chest";
                    break;

                case 3: // - Used for human NPC stomach and pelvis, appears Yellow in HLMV
                    returnType = "Stomach";
                    break;

                case 4: // - Used for human Left Arm, appears Deep Blue in HLMV
                    returnType = "Left_Arm";
                    break;

                case 5: // - Used for human Right Arm, appears Bright Violet in HLMV
                    returnType = "Right_Arm";
                    break;

                case 6: // - Used for human Left Leg, appears Bright Cyan in HLMV
                    returnType = "Left_Leg";
                    break;

                case 7: // - Used for human Right Leg, appears White like the default group in HLMV
                    returnType = "Right_Leg";
                    break;

                case 8: // - Used for human neck (to fix penetration to head from behind), appears Orange in HLMV (in all games since Counter-Strike: Global Offensive)
                    returnType = "Neck";
                    break;

                default: // - the default group of hitboxes, appears White in HLMV
                    returnType = "Generic";
                    break;
            }
            return returnType;
        }


        BoneWeight GetBoneWeight(mstudioboneweight_t mBoneWeight)
        {
            BoneWeight boneWeight = new BoneWeight();

            boneWeight.boneIndex0 = mBoneWeight.bone[0];
            boneWeight.boneIndex1 = mBoneWeight.bone[1];
            boneWeight.boneIndex2 = mBoneWeight.bone[2];

            boneWeight.weight0 = mBoneWeight.weight[0];
            boneWeight.weight1 = mBoneWeight.weight[1];
            boneWeight.weight2 = mBoneWeight.weight[2];

            return boneWeight;
        }

        #endregion

#if UNITY_EDITOR

        public Transform[] BoneTransforms;


#endif
        public JiggleBone[] JiggleBones;
        private mstudioseqdesc_t sequence;

        public void UpdateProceduralBones(float deltaTime)
        {
            foreach (var jiggleBone in MDL_JiggleBones)
            {
                Transform[] Bones = new Transform[MDL_Header.bone_count];
                Transform bone = Bones[jiggleBone.bone];
                var jiggle = new JiggleBone(bone);
                jiggle.Update(Time.deltaTime, transform.position);
            }

        }
        #region Shape Keys/Blend Shapes for Expressions
        public static void ApplyShapeKeyAnimation(SkinnedMeshRenderer meshRenderer, Flex[] flexes)
        {
            Mesh mesh = meshRenderer.sharedMesh;
            foreach (Flex flex in flexes)
            {
                Vector3[] deltaVertices = new Vector3[mesh.vertexCount];
                Vector3[] deltaNormals = new Vector3[mesh.vertexCount];
                foreach (var anim in flex.VertexAnimations)
                {
                    deltaVertices[anim.Index] = anim.PositionDelta;
                    deltaNormals[anim.Index] = anim.NormalDelta;
                }
                mesh.AddBlendShapeFrame(flex.Name, 100f, deltaVertices, deltaNormals, null);
            }
        }
        #endregion


        public struct PoseParameter
        {
            public string Name;
            public int Index;
            public float MinValue;
            public float MaxValue;
            public float DefaultValue;
            public AnimationCurve[] Curve;
        }

        PoseParameter[] poseParameters;
        PoseParameter[] LoadPoseParameters(uReader fileStream)
        {

            for (int i = 0; i < MDL_Header.localposeparam_count; i++)
            {
                PoseParameter parameter = new PoseParameter
                {
                    Name = fileStream.ReadNullTerminatedString(),
                    MinValue = fileStream.ReadInt64(),
                    MaxValue = fileStream.ReadInt64(),
                    DefaultValue = fileStream.ReadInt64()
                };
                poseParameters.Append(parameter);
            }

            return poseParameters.ToArray();
        }


        public class VertexAnimation
        {
            public int Index;
            public Vector3 PositionDelta;
            public Vector3 NormalDelta;
            internal static VertexAnimation FromBuffer(BinaryReader reader)
            {
                return new VertexAnimation
                {
                    Index = reader.ReadInt32(),

                    PositionDelta = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle()),

                    NormalDelta = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle()),

                    VertexDelta = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle())
                };
            }

            public Vector3 VertexDelta { get; internal set; }
        }

        public class Eyeball
        {
            public string[] Name;
            public int[] BoneIndex;
            public float[] Radius;
            public Vector3[] Position;
            public string[] Material;
            public float[] IrisScale;

            public Texture Texture { get; internal set; }
            public float SpecularIntensity { get; internal set; }
            public float SpecularPower { get; internal set; }
            public float ReflectionIntensity { get; internal set; }
            public Texture ReflectionTexture { get; internal set; }
            public float IrisSize { get; internal set; }
            public Texture IrisTexture { get; internal set; }
            public float PupilOffset { get; internal set; }
            public float PupilScale { get; internal set; }
            public Texture PupilTexture { get; internal set; }
        }
        public class JiggleBone
        {
            public Transform BoneTransform;
            private Vector3 currentPosition;
            private Vector3 velocity;
            private Vector3 acceleration;

            private Vector3 goalPosition; // Resting position
            private Vector3 gravity = new Vector3(0, -9.81f, 0);
            private float gravityScale = 1.0f;

            public float Stiffness = 0.5f;  // How strongly the bone returns to its goal position
            public float Damping = 0.2f;    // How much oscillation is reduced over time
            public float Mass = 1.0f;       // Bone "weight"
            public float Length = 1.0f;     // Max distance allowed from the base position

            private static readonly MDLFile mdlFile;

            public JiggleBone(Transform boneTransform)
            {
                BoneTransform = boneTransform;
                currentPosition = boneTransform.position;
                goalPosition = boneTransform.position;
                velocity = Vector3.zero;
            }

            public void Update(float deltaTime, Vector3 basePosition)
            {
                Vector3 displacement = goalPosition - currentPosition;
                Vector3 springForce = displacement * Stiffness;

                Vector3 dampingForce = -velocity * Damping;

                Vector3 gravityForce = gravity * gravityScale;

                acceleration = (springForce + dampingForce + gravityForce) / Mass;

                velocity += acceleration * deltaTime;
                currentPosition += velocity * deltaTime;

                Vector3 direction = (currentPosition - basePosition).normalized;
                currentPosition = basePosition + direction * Mathf.Min(Length, Vector3.Distance(currentPosition, basePosition));

                BoneTransform.position = currentPosition;
                SmoothRotation(basePosition);
            }

            private void SmoothRotation(Vector3 basePosition)
            {
                Vector3 direction = (currentPosition - basePosition).normalized;
                Quaternion targetRotation = Quaternion.LookRotation(direction);
                BoneTransform.rotation = Quaternion.Slerp(BoneTransform.rotation, targetRotation, 0.1f);
            }







            private void SmoothlyUpdateBoneRotation(Vector3 basePosition, float deltaTime)
            {
                Vector3 directionToCurrent = (currentPosition - basePosition).normalized;
                Quaternion targetRotation = Quaternion.LookRotation(directionToCurrent);

                float rotationStep = 0 * deltaTime;
                BoneTransform.rotation = Quaternion.RotateTowards(BoneTransform.rotation, targetRotation, rotationStep);

                BoneTransform.rotation = Quaternion.Slerp(BoneTransform.rotation, targetRotation, Damping * deltaTime);
            }


            public static void AdjustLengthBasedOnSpeed(float speed, float minLength, float maxLength)
            {
                minLength = Mathf.Lerp(minLength, maxLength, speed);
            }
            public static void Use_UpdateWindSettings() { UpdateWindSettings(new Vector3(), new float()); }
            public static void UpdateWindSettings(Vector3 newDirection, float newStrength)
            {

            }
        }



        public class EyeballData
        {
            public Vector3[] Position;
            public Vector3[] UpDirection;
            public Vector3[] ForwardDirection;
            public float[] Radius;
            public float[] ZOffset;
        }

        public class BoneAnimationFrame
        {
            public int[] BoneIndex;
            public Vector3[] Position;
            public Quaternion[] Rotation;

        }


        public GameObject TargetGameObject { get; set; }
        public float positionCurveZ { get; private set; }
        public float positionCurveY { get; private set; }
        public float positionCurveX { get; private set; }
        public Animation[] AnimComponent { get; private set; }
        public string ForwardDirection { get; private set; }
        public string UpDirection { get; private set; }
        public string ZOffset { get; private set; }
        public string IrisScale { get; private set; }



        private KeyValuePair<string, string[]> MapAssociatedFiles(string modelName, string directoryPath, string[] fileExtensions)
        {
            var associatedFiles = new KeyValuePair<string, string[]>();
            string[] extensions = new[] { ".vta", ".dmx", ".smd" };
            var mappedFiles = MapAssociatedFiles(modelName, directoryPath, extensions);

            foreach (var ext in fileExtensions)
            {
                string searchPattern = $"*{ext}";
                string[] files = Directory.GetFiles(directoryPath, searchPattern);

                foreach (var file in files)
                {
                    string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(file);

                    if (fileNameWithoutExtension.Contains(modelName, StringComparison.OrdinalIgnoreCase))
                    {
                        Debug.Log($"Powiązany plik {ext} znaleziony: {file}");


                    }
                }
            }

            return associatedFiles;
        }


        public static string ResolveFileName(string requestedName, KeyValuePair<string, string[]> fileMapping)
        {
            foreach (var entry in fileMapping.Value)
            {
                if (requestedName.Contains(entry, StringComparison.OrdinalIgnoreCase))
                {
                    return entry; // Return the matched file name
                }
            }

            return requestedName;
        }


        string modelPath = "path/to/model.mdl";
        private static Stream FileInput;
        private AnimationClip clip;

        private void Use_ProcessFile()
        {

            Use_ProcessFile();
        }



        public void OverrideReferences(MDLFile mdlFile, KeyValuePair<string, string[]> fileMapping)
        {
            foreach (var flex in mdlFile.MDL_FlexDescs)
            {
                string oldName = flex.pszFACS(new byte[0], 1);
                string newName = ResolveFileName(oldName, fileMapping);

                Debug.Log($"Podmiana pliku: {oldName} -> {newName}");
                flex.pszFACS(new byte[0], 1);
            }
        }


        public static void LogModelErrors(MDLFile mdlFile)
        {
            if (mdlFile.MDL_Header.id == 0)
            {
            }

            if (mdlFile.MDL_FlexDescs == null || mdlFile.MDL_FlexDescs == null)
            {
            }

            if (mdlFile.MDL_StudioBones == null || mdlFile.MDL_StudioBones.Length == 0)
            {
            }// Example usage of OverrideReferences:


        }

        private static AnimationCurve CreateCurve(Transform[] bones, string boneName, float time, float value)
        {
            AnimationCurve curve = new AnimationCurve();
            curve.AddKey(new Keyframe(time, value));
            return curve;
        }
    }




}







#region Bones Setup
#endregion
#endregion




public static class MDLUtilities
{
    public static string GetSequenceName(this MDLFile mdlFile, mstudioseqdesc_t sequence)
    {
        if (sequence.szlabelindex != 0)
        {
            return ReadNullTerminatedString(mdlFile.mdldata, sequence.szlabelindex);
        }
        return "UnnamedAnimation";
    }

    private static string ReadNullTerminatedString(byte[] data, int offset)
    {
        int length = 0;
        while (offset + length < data.Length && data[offset + length] != 0)
        {
            length++;
        }
        return System.Text.Encoding.UTF8.GetString(data, offset, length);
    }
}


#endif