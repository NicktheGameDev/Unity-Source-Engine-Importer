// Assets/Editor/QcAssetImporter.cs
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using USource.Model.Flex;

public class QcAssetImporter : AssetPostprocessor { }
