﻿namespace AdvancedHashTables
{
    public class UtlHashHandle
    {
    }
}