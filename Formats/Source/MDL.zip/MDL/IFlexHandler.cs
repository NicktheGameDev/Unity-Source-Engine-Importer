

using UnityEngine;

using uSource.Formats.Source.MDL;

public interface IFlexHandler
{
    void ConvertFlexesToBlendShapes(MDLFile mdlFile);
}
