    // UNITY_WRAPPED - Crowbar sources excluded from Unity compilation
    #if !UNITY_2018_1_OR_NEWER
    ﻿//INSTANT C# NOTE: Formerly VB project-level imports:
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

namespace Crowbar
{
	public class SourceMdlVertAnimWrinkle : SourceMdlVertAnim
	{
		//FROM: SourceEngineXXXX_source\public\studio.h
		//// this is the memory image of vertex anims (16-bit fixed point)
		//struct mstudiovertanim_wrinkle_t : public mstudiovertanim_t
		//{
		//	DECLARE_BYTESWAP_DATADESC();

		//	short	wrinkledelta;

		//	inline void SetWrinkleFixed( float flWrinkle )
		//	{
		//		int nWrinkleDeltaInt = flWrinkle * g_VertAnimFixedPointScaleInv;
		//		wrinkledelta = clamp( nWrinkleDeltaInt, -32767, 32767 );
		//	}

		//	inline Vector4D GetDeltaFixed()
		//	{
		//		return Vector4D( delta[0]*g_VertAnimFixedPointScale, delta[1]*g_VertAnimFixedPointScale, delta[2]*g_VertAnimFixedPointScale, wrinkledelta*g_VertAnimFixedPointScale );
		//	}

		//	inline void GetDeltaFixed4DAligned( Vector4DAligned *vFillIn )
		//	{
		//		vFillIn->Set( delta[0]*g_VertAnimFixedPointScale, delta[1]*g_VertAnimFixedPointScale, delta[2]*g_VertAnimFixedPointScale, wrinkledelta*g_VertAnimFixedPointScale );
		//	}
		//};



		public short wrinkleDelta;

	}

}
    #endif
