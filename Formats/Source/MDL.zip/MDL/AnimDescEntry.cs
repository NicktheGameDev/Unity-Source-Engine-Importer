// Assets/uSource-master/Formats/Source/MDL/AnimDescEntry.cs
using uSource.Formats.Source.MDL;

namespace uSource.formats.source.mdl
{
    /// Struktura pomocnicza: opis animacji + jej pozycja w pliku MDL

}